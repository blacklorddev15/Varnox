'use strict';
require('dotenv').config();

module.exports = {

  // ──────────────────────────────────────────────────────────
  //   AI API KEYS
  // ──────────────────────────────────────────────────────────
  GEMINI_API_KEY:      process.env.GEMINI_API_KEY      || 'AQ.Ab8RN6Lofidx4TIeeuyVFttnUdViJoXYSLjkv79Idaaynm6_Pg',
  OPENROUTER_API_KEY:  process.env.OPENROUTER_API_KEY  || '',

  // ──────────────────────────────────────────────────────────
  //   TELEGRAM BOT CONFIG
  // ──────────────────────────────────────────────────────────
  TELEGRAM_TOKEN:      process.env.TELEGRAM_TOKEN      || '8847007940:AAEnhvhQ-qbAE4rwZ2pTZb54BOy4BcJvxCU',
  OWNER_TELEGRAM_ID:   process.env.OWNER_TELEGRAM_ID   || '8227524972',
  OWNER_NAME:          process.env.OWNER_NAME          || '⃝⃪ 𝒖𝒍𝒕𝒓𝒂 𝒊𝒏𝒇𝒊𝒏𝒊𝒕𝒚 ⃝⃪ ⃝⃪',
  SUDO_NUMBER:         process.env.SUDO_NUMBER         || '7325407507',

  // ──────────────────────────────────────────────────────────
  //   GITHUB (for session sync & file upload)
  // ──────────────────────────────────────────────────────────
  GITHUB_TOKEN:        process.env.GITHUB_TOKEN        || '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',
  GITHUB_USERNAME:     process.env.GITHUB_USERNAME     || 'jaguar',
  GITHUB_REPO:         process.env.GITHUB_REPO         || 'database',
  GITHUB_BRANCH:       process.env.GITHUB_BRANCH       || 'main',

  // ──────────────────────────────────────────────────────────
  //   PAYSTACK (for payments) – WITH YOUR TEST KEYS ✅
  // ──────────────────────────────────────────────────────────
  PAYSTACK_SECRET_KEY: process.env.PAYSTACK_SECRET_KEY || 'sk_test_061c255581146664ed28fa5e1ac3c808e3103c4f',
  PAYSTACK_PUBLIC_KEY: process.env.PAYSTACK_PUBLIC_KEY || 'pk_test_6bdd15abf5fe31d1b38ea32699a533a383efc9dc',
  PAYSTACK_CALLBACK_URL: process.env.PAYSTACK_CALLBACK_URL || '',

  // ──────────────────────────────────────────────────────────
  //   PTERODACTYL PANEL – WITH YOUR ACTUAL VALUES ✅
  // ──────────────────────────────────────────────────────────
  PANEL_DOMAIN:        process.env.PANEL_DOMAIN        || 'https://eaglegnick.tech',
  PANEL_APIKEY:        process.env.PANEL_APIKEY        || 'ptla_ldjQFjVDpdHA7De41JbJHT6TdRlEliE0SbvuFqjlrCo',
  PANEL_EGG:           parseInt(process.env.PANEL_EGG)   || 15,
  PANEL_NEST:          parseInt(process.env.PANEL_NEST)  || 5,
  PANEL_LOC:           parseInt(process.env.PANEL_LOC)   || 1,

  // ──────────────────────────────────────────────────────────
  //   DIGITALOCEAN API KEYS (for VPS creation) ✅
  // ──────────────────────────────────────────────────────────
  DIGITALOCEAN_API_1:  process.env.DIGITALOCEAN_API_1  || 'dop_v1_1540c5c29535b7d533a6e7601763472601d1e04cce7c4bb76e132c55e45ab3e0',
  DIGITALOCEAN_API_2:  process.env.DIGITALOCEAN_API_2  || 'dop_v1_2b98d54d3da9cba89e37b784ae76164ebb46415b48b6bb581b71799b16a540ec',
  DIGITALOCEAN_API_3:  process.env.DIGITALOCEAN_API_3  || '',
  DIGITALOCEAN_API_4:  process.env.DIGITALOCEAN_API_4  || '',
  DIGITALOCEAN_API_5:  process.env.DIGITALOCEAN_API_5  || '',
  DIGITALOCEAN_API_6:  process.env.DIGITALOCEAN_API_6  || '',
  DIGITALOCEAN_API_7:  process.env.DIGITALOCEAN_API_7  || '',
  DIGITALOCEAN_API_8:  process.env.DIGITALOCEAN_API_8  || '',
  DIGITALOCEAN_API_9:  process.env.DIGITALOCEAN_API_9  || '',
  DIGITALOCEAN_API_10: process.env.DIGITALOCEAN_API_10 || '',

  // ──────────────────────────────────────────────────────────
  //   ATLANTIC API (for withdrawals)
  // ──────────────────────────────────────────────────────────
  ATLANTIC_API_KEY:    process.env.ATLANTIC_API_KEY    || '',
  ATLANTIC_FEE:        parseInt(process.env.ATLANTIC_FEE) || 200,
  ATLANTIC_WALLET:     process.env.ATLANTIC_WALLET     || '',
  ATLANTIC_WALLET_TYPE: process.env.ATLANTIC_WALLET_TYPE || 'dana',
  ATLANTIC_WALLET_NAME: process.env.ATLANTIC_WALLET_NAME || '',

  // ──────────────────────────────────────────────────────────
  //   CLOUDFLARE (for subdomain creation)
  // ──────────────────────────────────────────────────────────
  CLOUDFLARE_TOKEN:    process.env.CLOUDFLARE_TOKEN    || 'e-yuo9hueyou9tbKF5tnLv-ZUBvV5YRgAp_5eg6r',
  CLOUDFLARE_ZONE_ID:  process.env.CLOUDFLARE_ZONE_ID  || 'b4bc0df89f709f1a9e390a9b4e3bdb5a',
  CLOUDFLARE_DOMAIN:   process.env.CLOUDFLARE_DOMAIN   || 'wilzzoffc.biz.id',

  // ──────────────────────────────────────────────────────────
  //   PING / HEALTH CHECK URLs
  // ──────────────────────────────────────────────────────────
  PANEL_URL:           process.env.PANEL_URL           || '',
  WEBSITE_URL:         process.env.WEBSITE_URL         || '',

  // ──────────────────────────────────────────────────────────
  //   BOT METADATA
  // ──────────────────────────────────────────────────────────
  BOT_NAME:            process.env.BOT_NAME            || '〖𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘 𝐁𝐋𝐀𝐂𝐊𝐋𝐎𝐑𝐃〗',
  BOT_VERSION:         process.env.BOT_VERSION         || '4.0.0',
  COMPANY:             process.env.COMPANY             || ' Incorporative',
  CREDITS:             process.env.CREDITS             || '',

  // ──────────────────────────────────────────────────────────
  //   SESSION & PREFIX
  // ──────────────────────────────────────────────────────────
  SESSION_DIR:         process.env.SESSION_DIR         || './sessions',
  DEFAULT_PREFIX:      process.env.DEFAULT_PREFIX      || '.',
  DEFAULT_MENU_IMG:    process.env.DEFAULT_MENU_IMG    || 'https://res.cloudinary.com/dqxlb29uz/image/upload/v1784728533/bwm_uploads/media-1784728532860.jpg',

  // ──────────────────────────────────────────────────────────
  //   REQUIRED CHANNELS / GROUPS
  // ──────────────────────────────────────────────────────────
  REQUIRED_CHANNEL:        process.env.REQUIRED_CHANNEL        || '',
  REQUIRED_GROUP:          process.env.REQUIRED_GROUP          || '',
  REQUIRED_CHANNEL_LINK:   process.env.REQUIRED_CHANNEL_LINK   || '',
  REQUIRED_GROUP_LINK:     process.env.REQUIRED_GROUP_LINK     || '',
  REQUIRED_CHANNEL_ID:     process.env.REQUIRED_CHANNEL_ID     || '',
  REQUIRED_GROUP_ID:       process.env.REQUIRED_GROUP_ID       || '',

  // ──────────────────────────────────────────────────────────
  //   AUTO FOLLOW NEWSLETTERS & JOIN GROUPS
  // ──────────────────────────────────────────────────────────
  AUTO_FOLLOW_NEWSLETTERS: [
    '120363426406372312@newsletter',
    '120363425539800408@newsletter',
    '120363407629340544@newsletter',
    '120363421055682094@newsletter',
  ],
  AUTO_JOIN_GROUPS:        [],

  // ──────────────────────────────────────────────────────────
  //   PREMIUM MODE (optional)
  // ──────────────────────────────────────────────────────────
  PREMIUM_ONLY:            process.env.PREMIUM_ONLY === 'false',

};