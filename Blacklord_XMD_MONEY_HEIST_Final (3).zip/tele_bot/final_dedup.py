import re
import os

file_path = "/home/ubuntu/tele_bot/case.js"

with open(file_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

# 1. Identify triggers outside the integration block
native_triggers = set()
in_integration = False
for line in lines:
    if "// ── Ultimate Inclusive Command Integration ──" in line:
        in_integration = True
        continue
    if in_integration:
        if "case 'menu':" in line and "case 'menu': {" in line:
            in_integration = False
        else:
            continue
    
    m = re.search(r"case\s+['\"]([^'\"]+)['\"]", line)
    if m:
        native_triggers.add(m.group(1).lower().strip())

print(f"Found {len(native_triggers)} native triggers.")

# 2. Process the file and remove duplicates from the integration block
new_lines = []
in_integration = False
skip_until_break = False
brace_depth = 0
seen_in_integration = set()

for line in lines:
    if "// ── Ultimate Inclusive Command Integration ──" in line:
        in_integration = True
        new_lines.append(line)
        continue
    
    if in_integration:
        if "case 'menu':" in line and "case 'menu': {" in line:
            in_integration = False
            new_lines.append(line)
            continue
        
        if skip_until_break:
            brace_depth += line.count("{")
            brace_depth -= line.count("}")
            if "break;" in line and brace_depth <= 0:
                # We also need to catch the closing brace if it's on the next line or same line
                if "}" in line and brace_depth <= 0:
                    skip_until_break = False
                continue
            if brace_depth < 0: # Probably hit the end
                skip_until_break = False
            continue

        m = re.search(r"case\s+['\"]([^'\"]+)['\"]", line)
        if m:
            trigger = m.group(1).lower().strip()
            if trigger in native_triggers or trigger in seen_in_integration:
                print(f"Removing duplicate integration case: {trigger}")
                skip_until_break = True
                brace_depth = 0
                continue
            else:
                seen_in_integration.add(trigger)
                new_lines.append(line)
        else:
            new_lines.append(line)
            brace_depth += line.count("{")
            brace_depth -= line.count("}")
    else:
        new_lines.append(line)

with open(file_path, "w", encoding="utf-8") as f:
    f.write("".join(new_lines))

print("Final de-duplication complete!")
