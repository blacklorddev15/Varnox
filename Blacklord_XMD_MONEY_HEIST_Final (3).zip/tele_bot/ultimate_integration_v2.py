import os
import re
import json

bot_dir = "/home/ubuntu/tele_bot"
commands_path = os.path.join(bot_dir, "commands")
case_path = os.path.join(bot_dir, "case.js")
original_case_path = "/home/ubuntu/original_case.js"

with open(original_case_path, "r", encoding="utf-8") as f:
    content = f.read()

# 1. Identify EXPLICIT native cases (only active ones)
native_cases = set()
for line in content.splitlines():
    line = line.strip()
    if line.startswith("case '") or line.startswith('case "'):
        m = re.search(r"case\s+['\"]([^'\"]+)['\"]", line)
        if m:
            native_cases.add(m.group(1).lower().strip())
print(f"Found {len(native_cases)} explicit active native cases in original file.")

# 2. Extract ALL blacklord commands
all_blacklord_modules = []
for root, dirs, files in os.walk(commands_path):
    for file in files:
        if file.endswith(".js"):
            filepath = os.path.join(root, file)
            rel_path = "./" + os.path.relpath(filepath, bot_dir).replace("\\", "/")
            category = os.path.basename(root).upper()
            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                    file_content = f.read()
                
                # Find name and aliases
                name_matches = list(re.finditer(r"name\s*:\s*['\"]([^'\"]+)['\"]", file_content))
                if not name_matches: continue
                
                for i, match in enumerate(name_matches):
                    name = match.group(1).lower().strip()
                    start = 0 if i == 0 else name_matches[i-1].end()
                    end = len(file_content) if i == len(name_matches)-1 else name_matches[i+1].start()
                    chunk = file_content[start:end]
                    
                    aliases = []
                    a_m = re.search(r"aliases\s*:\s*\[([^\]]+)\]", chunk)
                    if a_m: aliases.extend([a.lower().strip() for a in re.findall(r"['\"]([^'\"]+)['\"]", a_m.group(1))])
                    
                    all_blacklord_modules.append({
                        "primary": name,
                        "aliases": list(set(aliases)),
                        "rel_path": rel_path,
                        "category": category
                    })
            except: pass

# 3. Add Extra features from user list
extra_features = [
    {"primary": "carbon", "aliases": ["code"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "magic8", "aliases": ["8ball"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "roast", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "riddle", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "trivia", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "ai", "aliases": ["chatgpt", "gpt", "openai", "gemini"], "rel_path": "./commands/extra/extra_features.js", "category": "AI"}
]
all_blacklord_modules.extend(extra_features)

# 4. Filter: Only skip if it's an EXPLICIT native case
final_modules = []
seen_triggers = set(native_cases)

# Sort alphabetically to keep case.js organized
for mod in sorted(all_blacklord_modules, key=lambda x: x["primary"]):
    if mod["primary"] in native_cases:
        continue
    
    # Filter aliases
    unique_aliases = []
    for a in mod["aliases"]:
        if a not in seen_triggers:
            unique_aliases.append(a)
            seen_triggers.add(a)
    
    seen_triggers.add(mod["primary"])
    final_modules.append({
        "primary": mod["primary"],
        "aliases": unique_aliases,
        "rel_path": mod["rel_path"],
        "category": mod["category"]
    })

print(f"Integrating {len(final_modules)} unique command modules.")

with open("/home/ubuntu/integrated_modules.json", "w") as f:
    json.dump(final_modules, f, indent=2)

# 5. Generate JS code
cases_code = "\n  // ── Ultimate Inclusive Command Integration ──\n"
for mod in final_modules:
    triggers = [mod["primary"]] + mod["aliases"]
    for t in triggers:
        cases_code += f"    case '{t}':\n"
    
    cases_code += f"    {{\n      try {{\n        const exported = require('{mod['rel_path']}');\n        const blacklordCmd = Array.isArray(exported) ? exported.find(c => c.name === '{mod['primary']}') : exported;\n        const extra = {{ from, sender, pushname, reply: async (text, opts) => await sock.sendMessage(from, {{ text }}, {{ quoted: m, ...opts }}), args, text, prefix: storedPrefix }};\n        await blacklordCmd.execute(sock, m, args, extra);\n      }} catch (err) {{ console.error('[CMD-ERR] {mod['primary']}:', err); await reply('❌ Error: ' + err.message); }}\n      break;\n    }}\n"

# 6. Inject into case.js
target_switch = "switch (cmd) {"
if target_switch in content:
    content = content.replace(target_switch, target_switch + "\n" + cases_code, 1)

# 7. Add styled menu logic
# I'll use the logic I wrote earlier
blacklord_categories = {}
for mod in final_modules:
    cat = mod["category"]
    if cat not in blacklord_categories: blacklord_categories[cat] = []
    blacklord_categories[cat].append(mod["primary"])

blacklord_menu_str = ""
for cat in sorted(blacklord_categories.keys()):
    blacklord_menu_str += f"\\n> ╭═━⪩ 〖  {cat}  〗═══━•⩵꙰ཱི࿐\\n"
    for cmd in sorted(blacklord_categories[cat]):
        blacklord_menu_str += f"> │❍ {cmd}\\n"
    blacklord_menu_str += f"> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐"

# Find menu case in original content and replace it
styled_menu_logic = """    case 'menu': {
      await reaction('🌹');
      const style = c.menuStyle || '1';
      const myName = pushname || 'User';
      const myNumber = senderNumber || 'Unknown';
      const myStatus = _isOwner ? '𝗢𝘄𝗻𝒆𝗿' : isPremium ? '𝗣𝗿𝗲𝗺𝒊𝒖𝗺' : '𝗙𝒓𝒆𝒆';
      const myUptime = typeof runtime === 'function' ? runtime(process.uptime()) : formatUptime(process.uptime() * 1000);
      const botName = c.botName || '𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓';
      
      const styles = {
        '1': { h: '•━═ 〘  ' + botName + '  〙═━•\\n> ╭═━⪩〘⚡𝐁𝝝𝐓 𝐒𝐓Λ𝐓𝐔𝐒⚡ 〙•━•⩵꙰ཱི࿐', s: '\\n> │⫹⫺ 𝗣𝗿𝗲𝘆        : ' + myName + '\\n> │⫹⫺ 𝗦𝗶𝗴𝗶𝗹       : ' + myNumber + '\\n> │⫹⫺ 𝗗𝗼𝗺𝗶𝗻𝗶𝗼𝗻    : ' + myStatus + '\\n> │⫹⫺ 𝗖𝗼𝘂𝗻𝘁𝗱𝗼𝘄𝗻  : ' + myUptime + '\\n> ╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐', p: '> │❍ ', ch: '> ╭═━⪩ 〖  ', cf: '  〗═══━•⩵꙰ཱི࿐', f: '> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐' },
        '2': { h: '┏━━━ 〘 ' + botName + ' 〙 ━━━┓\\n┃ ⚡ 𝐒𝐓𝐀𝐓𝐔𝐒 ⚡', s: '\\n┃ 👤 User: ' + myName + '\\n┃ 🔢 Num: ' + myNumber + '\\n┃ 🎖️ Rank: ' + myStatus + '\\n┃ ⏳ Up: ' + myUptime + '\\n┗━━━━━━━━━━━━━━━━━━━━━━┛', p: '┃ ❍ ', ch: '\\n┏━━━ 〖 ', cf: ' 〗 ━━━┓', f: '┗━━━━━━━━━━━━━━━━━━━━┛' },
        '3': { h: '╔════ ≪ ' + botName + ' ≫ ════╗\\n║ 💠 ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ', s: '\\n║ 👤 ɴᴀᴍᴇ: ' + myName + '\\n║ 📱 ɴᴜᴍ: ' + myNumber + '\\n║ 🏆 ʀᴀɴᴋ: ' + myStatus + '\\n║ 🕒 ᴜᴘ: ' + myUptime + '\\n╚════════════════════════╝', p: '║ 💠 ', ch: '\\n╔═══〖 ', cf: ' 〗═══╗', f: '╚════════════════════╝' },
        '4': { h: '✨ ━━━ ' + botName + ' ━━━ ✨\\n👑 𝗨𝗦𝗘𝗥 𝗣𝗥𝗢𝗙𝗜𝗟𝗘', s: '\\n👤 𝗡𝗮𝗺𝒆: ' + myName + '\\n📱 𝗡ᴜ𝗺: ' + myNumber + '\\n🏆 𝗥ａｎｋ: ' + myStatus + '\\n🕒 𝗨𝗽: ' + myUptime + '\\n✨ ━━━━━━━━━━━━━━━━━━ ✨', p: '◈ ', ch: '\\n✨ ━━ ', cf: ' ━━ ✨', f: '✨ ━━━━━━━━━━━━━━ ✨' },
        '5': { h: '┌────── ' + botName + ' ──────┐\\n│ 📊 𝐒𝐘𝐒𝐓𝐄𝐌 𝐒𝐓𝐀𝐓𝐒', s: '\\n│ 👤 USER: ' + myName + '\\n│ 📱 JID: ' + myNumber + '\\n│ 🎖️ ROLE: ' + myStatus + '\\n│ ⏳ RUN: ' + myUptime + '\\n└──────────────────────┘', p: '├─ ', ch: '\\n┌─── ', cf: ' ───┐', f: '└────────────────────┘' },
        '6': { h: '〔 ' + botName + ' 〕\\n┠─ 🛠 ᴘᴀɴᴇʟ', s: '\\n┠ 👤 User: ' + myName + '\\n┠ 📱 ID: ' + myNumber + '\\n┠ 🎖️ Rank: ' + myStatus + '\\n┠ ⏳ Up: ' + myUptime + '\\n┖──────────────────────', p: '│ ', ch: '\\n┠─ ', cf: '', f: '┖────────────────────' },
        '7': { h: '|--- ' + botName + ' ---|\\n| > STATUS', s: '\\n| User: ' + myName + '\\n| Num: ' + myNumber + '\\n| Rank: ' + myStatus + '\\n| Up: ' + myUptime + '\\n|-------------------|', p: '- ', ch: '\\n[ ', cf: ' ]', f: '|--------------------|' },
        '8': { h: '🎮 ' + botName + ' HUB\\n🕹️ PLAYER DATA', s: '\\n👤 PLAYER: ' + myName + '\\n🆔 ID: ' + myNumber + '\\n🏅 LEVEL: ' + myStatus + '\\n⏱️ SESSION: ' + myUptime + '\\n🎮 ━━━━━━━━━━━━━━━━━━ 🎮', p: '🕹️ ', ch: '\\n🎮 ', cf: '', f: '🎮 ━━━━━━━━━━━━━━ 🎮' },
        '9': { h: '🚀 ' + botName + ' CORE\\n🛰️ TELEMETRY', s: '\\n🛰️ NODE: ' + myName + '\\n📡 ADDR: ' + myNumber + '\\n🛡️ AUTH: ' + myStatus + '\\n⏱️ SYNC: ' + myUptime + '\\n🚀 ━━━━━━━━━━━━━━━━━━ 🚀', p: '🚀 ', ch: '\\n🚀 ', cf: '', f: '🚀 ━━━━━━━━━━━━━━ 🚀' },
        '10': { h: '[ ' + botName + ' ]\\n>> SYSTEM.LOG', s: '\\nUSER::' + myName + '\\nADDR::' + myNumber + '\\nRANK::' + myStatus + '\\nUPTIME::' + myUptime + '\\n[ END LOG ]', p: '> ', ch: '\\n# SECTION: ', cf: '', f: '----------------------' }
      };

      const cur = styles[style] || styles['1'];
      // Original cmdList string from case.js
      const cmdListStr = `""" + re.search(r"const cmdList = `(.*?)`;", content, re.DOTALL).group(1) + """`;
      const blacklordAdditionsStr = `""" + blacklord_menu_str + """`;

      const processList = (text) => {
        return text.replace(/> │❍ /g, cur.p)
                   .replace(/> ╭═━⪩ 〖 /g, cur.ch)
                   .replace(/ 〗═══━•⩵꙰ཱི࿐/g, cur.cf)
                   .replace(/> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐/g, cur.f);
      };

      const fullMenu = ft(cur.h + cur.s + processList(cmdListStr) + processList(blacklordAdditionsStr), sock);

      try {
        const menuImg = c.menuImg || settings.get('menuImg') || './media/menu.png';
        const imgBuf = await getBuffer(menuImg);
        await sock.sendMessage(jid, {
          image: imgBuf,
          caption: fullMenu,
          footer: botName,
          buttons: [{ buttonId: '.owner', buttonText: { displayText: 'Owner' }, type: 1 }],
          headerType: 4
        }, { quoted: m });
      } catch (e) {
        await reply(fullMenu);
      }
      break;
    }"""

m_start = content.find("case 'menu': {")
m_end = content.find("break;", m_start + 500) + 6
m_brace_end = content.find("}", m_end) + 1
content = content[:m_start] + styled_menu_logic + content[m_brace_end:]

# 8. Branding and Settings
content = content.replace("𝐁𝐋Λ𝐂𝐊𝐋𝐎𝐑𝐃 𝐗𝐌𝐃", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("𝐁𝐋Λ𝐂𝐊𝐋𝐎𝐑𝐃", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")

# Update setmenu
setmenu_pattern = r"case 'setmenu': \{.*?break;\s+\}"
setmenu_replacement = """case 'setmenu': {
  if (needOwner()) break;
  const v = args[0];
  if (!['v1','v2','v3','v4','v5','v6','v7','v8','v9','v10'].includes(v)) { 
    await reply(`📋 ${prefix}setmenu v1 to v10\\n\\nExample: ${prefix}setmenu v5`); 
    break; 
  }
  const settingsFile = DB('settings.json');
  const data = readJSON(settingsFile, {});
  data.menuStyle = v.replace('v', '');
  writeJSON(settingsFile, data);
  await reply(`✅ Menu style set to ${v}.`);
  break;
}"""
content = re.sub(setmenu_pattern, setmenu_replacement, content, flags=re.DOTALL)

# Update getBuffer
getbuffer_pattern = r"async function getBuffer\(url\) \{.*?return Buffer\.from\(res\.data\);\n\}"
getbuffer_replacement = """async function getBuffer(urlOrPath) {
  if (fs.existsSync(urlOrPath)) {
    return fs.readFileSync(urlOrPath);
  }
  const res = await axios.get(urlOrPath, { responseType: 'arraybuffer', timeout: 15000 });
  return Buffer.from(res.data);
}"""
content = re.sub(getbuffer_pattern, getbuffer_replacement, content, flags=re.DOTALL)

with open(case_path, "w", encoding="utf-8") as f:
    f.write(content)

print("Ultimate integration V2 complete!")
