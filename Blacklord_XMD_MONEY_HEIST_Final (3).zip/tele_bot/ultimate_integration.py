import os
import re
import json

bot_dir = "/home/ubuntu/tele_bot"
commands_path = os.path.join(bot_dir, "commands")
case_path = os.path.join(bot_dir, "case.js")
# We need the original Blacklord case.js logic. I'll use a backup if available or just read current and filter out my additions.
# Actually, I have the 'master' case.js which I've been patching.
# I'll try to find the 'switch (cmd) {' and remove everything between it and the first native case I know.
# Or better, I'll just use the case.js.bak I created earlier if it still exists.

# Let's check for case.js.bak
bak_path = "/home/ubuntu/tele_bot/case.js.bak"
if not os.path.exists(bak_path):
    # If not exists, I'll try to find it in the parent or elsewhere
    # For now, I'll assume I can just use the current case.js and strip out the 'Auto-Generated' section.
    with open(case_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    # Remove the previous auto-generated section
    content = re.sub(r"// ── Auto-Generated Unique Commands.*?// ─── SEARCH COMMANDS ───", "// ─── SEARCH COMMANDS ───", content, flags=re.DOTALL)
    # Actually, let's just use a clean version of case.js from the Tony45 zip if possible.
    # I'll just proceed with the current content and trust my regex.
else:
    with open(bak_path, "r", encoding="utf-8") as f:
        content = f.read()

# 1. Identify EXPLICIT native cases to avoid duplicates
native_cases = set(re.findall(r"case\s+['\"]([^'\"]+)['\"]", content))
print(f"Found {len(native_cases)} explicit native cases.")

# 2. Extract ALL blacklord commands
all_blacklord_modules = []
for root, dirs, files in os.walk(commands_path):
    for file in files:
        if file.endswith(".js"):
            filepath = os.path.join(root, file)
            rel_path = "./" + os.path.relpath(filepath, bot_dir).replace("\\", "/")
            category = os.path.basename(root).upper()
            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                    file_content = f.read()
                
                # Find name and aliases
                name_matches = list(re.finditer(r"name\s*:\s*['\"]([^'\"]+)['\"]", file_content))
                if not name_matches: continue
                
                for i, match in enumerate(name_matches):
                    name = match.group(1).lower().strip()
                    start = 0 if i == 0 else name_matches[i-1].end()
                    end = len(file_content) if i == len(name_matches)-1 else name_matches[i+1].start()
                    chunk = file_content[start:end]
                    
                    aliases = []
                    a_m = re.search(r"aliases\s*:\s*\[([^\]]+)\]", chunk)
                    if a_m: aliases.extend([a.lower().strip() for a in re.findall(r"['\"]([^'\"]+)['\"]", a_m.group(1))])
                    
                    all_blacklord_modules.append({
                        "primary": name,
                        "aliases": list(set(aliases)),
                        "rel_path": rel_path,
                        "category": category
                    })
            except: pass

# 3. Add Extra features from user list if missing
extra_features = [
    {"primary": "carbon", "aliases": ["code"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "magic8", "aliases": ["8ball"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "roast", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "riddle", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "trivia", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"}
]
all_blacklord_modules.extend(extra_features)

# 4. Filter: Only skip if it's an EXPLICIT native case
final_modules = []
seen_triggers = set(native_cases)

for mod in all_blacklord_modules:
    if mod["primary"] in native_cases:
        continue
    
    # Filter aliases
    unique_aliases = []
    for a in mod["aliases"]:
        if a not in seen_triggers:
            unique_aliases.append(a)
            seen_triggers.add(a)
    
    seen_triggers.add(mod["primary"])
    final_modules.append({
        "primary": mod["primary"],
        "aliases": unique_aliases,
        "rel_path": mod["rel_path"],
        "category": mod["category"]
    })

print(f"Integrating {len(final_modules)} unique command modules.")

# 5. Generate JS code
cases_code = "\n  // ── Ultimate Inclusive Command Integration ──\n"
for mod in final_modules:
    triggers = [mod["primary"]] + mod["aliases"]
    for t in triggers:
        cases_code += f"    case '{t}':\n"
    
    cases_code += f"    {{\n      try {{\n        const exported = require('{mod['rel_path']}');\n        const blacklordCmd = Array.isArray(exported) ? exported.find(c => c.name === '{mod['primary']}') : exported;\n        const extra = {{ from, sender, pushname, reply: async (text, opts) => await sock.sendMessage(from, {{ text }}, {{ quoted: m, ...opts }}), args, text, prefix: storedPrefix }};\n        await blacklordCmd.execute(sock, m, args, extra);\n      }} catch (err) {{ console.error('[CMD-ERR] {mod['primary']}:', err); await reply('❌ Error: ' + err.message); }}\n      break;\n    }}\n"

# 6. Inject into case.js
target_switch = "switch (cmd) {"
if target_switch in content:
    content = content.replace(target_switch, target_switch + "\n" + cases_code, 1)

# 7. Update Menu
categories = {}
for mod in final_modules:
    cat = mod["category"]
    if cat not in categories: categories[cat] = []
    categories[cat].append(mod["primary"])

blacklord_menu_str = ""
for cat in sorted(categories.keys()):
    blacklord_menu_str += f"\\n> ╭═━⪩ 〖  {cat}  〗═══━•⩵꙰ཱི࿐\\n"
    for cmd in sorted(categories[cat]):
        blacklord_menu_str += f"> │❍ {cmd}\\n"
    blacklord_menu_str += f"> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐"

# Find menu case and update it
# (Assuming the styled menu logic is already there or we need to re-apply it)
# I'll just search for 'blacklordAdditionsStr = `...`;' and replace it.
menu_patch = f"const blacklordAdditionsStr = `{blacklord_menu_str}`;"
content = re.sub(r"const blacklordAdditionsStr = `.*?`;", menu_patch, content, flags=re.DOTALL)

with open(case_path, "w", encoding="utf-8") as f:
    f.write(content)

print("Ultimate integration complete!")
