import re
import os

path = "/home/ubuntu/tele_bot/case.js"

# 1. Restore original case.js first to ensure clean state
original_case_path = "/home/ubuntu/original_bot/〖𝐁𝐋Λ𝐂𝐊𝐋𝐎𝐑𝐃 𝐗𝐌𝐃/tele-wa-bot45/case.js"
with open(original_case_path, "r", encoding="utf-8") as f:
    content = f.read()

# 2. Run the One True Fix (Integration)
# We'll just run the script I already have
os.system("python3 /home/ubuntu/tele_bot/one_true_fix.py")

# 3. Read the integrated case.js
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# 4. Global Branding
content = content.replace("BLACKLORD", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Blacklord", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Tony45", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("〖 𝐒𝚰𝐋𝚬𝚴𝐂𝚬𝚪 𝚵𝚳𝐃 〗", "〖 𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓 〗")
content = content.replace("𝐗𝐇𝐘𝐏𝐇𝐄𝐑   𝐏𝐑𝐎", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")

# 5. Inject the 10 Menu Styles
menu_styles_js = r"""    case 'menu': {
      await reaction('🌹');
      const style = c.menuStyle || '1';
      const myName = pushname || 'User';
      const myNumber = senderNumber || 'Unknown';
      const myStatus = _isOwner ? '𝗢𝘄𝗻𝗲𝗿' : isPremium ? '𝗣𝗿𝗲𝗺𝒊𝘂𝗺' : '𝗙𝒓𝗲𝒆';
      const myUptime = typeof runtime === 'function' ? runtime(process.uptime()) : formatUptime(process.uptime() * 1000);
      const botName = c.botName || '𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓';
      
      const styles = {
        '1': { h: `•━═ 〘  ${botName}  〙═━•\n> ╭═━⪩〘⚡𝐁𝝝𝐓 𝐒𝐓Λ𝐓𝐔𝐒⚡ 〙•━•⩵꙰ཱི࿐`, s: `\n> │⫹⫺ 𝗣𝗿𝗲𝘆        : ${myName}\n> │⫹⫺ 𝗦𝗶𝗴𝗶𝗹       : ${myNumber}\n> │⫹⫺ 𝗗𝗼𝗺𝗶𝗻𝗶𝗼𝗻    : ${myStatus}\n> │⫹⫺ 𝗖𝗼𝘂𝗻𝘁𝗱𝗼𝘄𝗻  : ${myUptime}\n> ╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐`, p: '> │❍ ', ch: '> ╭═━⪩ 〖  ', cf: '  〗═══━•⩵꙰ཱི࿐', f: '> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐' },
        '2': { h: `┏━━━━『 ${botName} 』━━━━┓`, s: `\n┃ ⚡ 𝗡𝗮𝗺𝗲: ${myName}\n┃ ⚡ 𝗨𝗽𝘁𝗶𝗺𝗲: ${myUptime}\n┗━━━━━━━━━━━━━━━━━━━━┛`, p: '┃ ◈ ', ch: '┏━━『 ', cf: ' 』━━┓', f: '┗━━━━━━━━━━┛' },
        '3': { h: `╔════════════════╗\n  ${botName}\n╚════════════════╝`, s: `\n👤 ${myName}\n⏱️ ${myUptime}`, p: '  ◦ ', ch: '┌──『 ', cf: ' 』', f: '└─────────' },
        '4': { h: `『 ${botName} 』`, s: `\n┠ 𝗨𝘀𝗲𝗿: ${myName}\n┠ 𝗧𝗶𝗺𝗲: ${myUptime}`, p: '┃ ', ch: '┯━『 ', cf: ' 』', f: '┷━━━━' },
        '5': { h: `══【 ${botName} 】══`, s: `\n◧ 𝗨𝘀𝗲𝗿: ${myName}\n◧ 𝗨𝗽𝘁𝗶𝗺𝗲: ${myUptime}`, p: '◽ ', ch: '══【 ', cf: ' 】══', f: '════════' },
        '6': { h: `✨ ${botName} ✨`, s: `\n👤 ${myName}\n⏳ ${myUptime}`, p: '🔹 ', ch: '💠 ', cf: ' 💠', f: '✨✨✨✨' },
        '7': { h: `◈ ${botName} ◈`, s: `\n⫹⫺ ${myName}\n⫹⫺ ${myUptime}`, p: '• ', ch: '◈ ', cf: ' ◈', f: '◈◈◈◈' },
        '8': { h: `『 ${botName} 』`, s: `\n┠ ${myName}\n┠ ${myUptime}`, p: '│ ', ch: '╭─ ', cf: ' ─╮', f: '╰────╯' },
        '9': { h: `★ ${botName} ★`, s: `\n👤 ${myName}\n🚀 ${myUptime}`, p: '☆ ', ch: '★ ', cf: ' ★', f: '★★★★' },
        '10': { h: `═══『 ${botName} 』═══`, s: `\n> 👤 ${myName}\n> 🚀 ${myUptime}`, p: '> ', ch: '══『 ', cf: ' 』══', f: '══════' }
      };
      
      const st = styles[style] || styles['1'];
      let menuText = st.h + st.s + '\n\n';
      
      for (const [cat, cmds] of Object.entries(CMDS)) {
        menuText += st.ch + cat + st.cf + '\n';
        for (const cmd of cmds) {
          menuText += st.p + cmd + '\n';
        }
        menuText += st.f + '\n\n';
      }
      
      const finalMenu = ft(menuText, sock);
      const menuImg = settings.DEFAULT_MENU_IMG || '/home/ubuntu/tele_bot/media/menu.png';
      
      await sock.sendMessage(jid, {
        image: { url: menuImg },
        caption: finalMenu,
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: settings.CHANNEL_JID || '120363407629340544@newsletter',
            newsletterName: '〖 𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓 〗'
          }
        }
      }, { quoted: m });
      break;
    }"""

# Replace all case 'menu' blocks
content = re.sub(r"case\s+['\"]menu['\"]\s*:\s*\{.*?break;\s*\}", menu_styles_js, content, flags=re.DOTALL)

# 6. Fix setmenu to support v1-v10
setmenu_js = """    case 'setmenu': {
      if (needOwner()) break;
      const v = args[0];
      if (!['v1','v2','v3','v4','v5','v6','v7','v8','v9','v10'].includes(v)) { 
        await reply(`📋 ${prefix}setmenu v1 to v10\\nExample: ${prefix}setmenu v5`); 
        break; 
      }
      const settingsFile = DB('settings.json');
      const data = readJSON(settingsFile, {});
      data.menuStyle = v.replace('v', '');
      writeJSON(settingsFile, data);
      await reply(`✅ Menu style set to ${v}.`);
      break;
    }"""
content = re.sub(r"case\s+['\"]setmenu['\"]\s*:\s*\{.*?break;\s*\}", setmenu_js, content, flags=re.DOTALL)

# 7. Final Safety Check for Stray Braces or Syntax
# We'll run the reconstructor later.

with open(path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Final Branding and Menu Style Fix complete!")
