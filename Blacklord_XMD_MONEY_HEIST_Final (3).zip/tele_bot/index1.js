// ============================================================
//   SAMSUNG XMD  –  COMPLETE INDEX.JS
//   Telegram + WhatsApp + Paystack + Pterodactyl Panel
//   + Panel Purchase Flow (buypanel, cpanel, verifypayment)
//   + Verify Payment Button after payment link
// ============================================================
'use strict';
require('dotenv').config();

const fs    = require('fs');
const path  = require('path');
const chalk = require('chalk');
const pino  = require('pino');
const https = require('https');
const http  = require('http');
const axios = require('axios');
const { Telegraf, Markup } = require('telegraf');

const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  DisconnectReason,
  proto,
  generateWAMessageFromContent,
} = require('@whiskeysockets/baileys');

const settings  = require('./settings');
const { handleMessage, runAutoFollow }  = require('./case');
const { handleAntiDelete, checkAntilink, checkAntiMedia, handleAntiCall, handleGroupParticipantsUpdate } = require('./helper/listeners');
const {
  sessionExists, listSessions, deleteSession, sessionDir,
  getWaSettings, setWaSetting, getAllPairs, getUserPairs,
  addPair, removePair,
  registerUser, getAllUsers, numOf,
} = require('./helper/function');
const { normalizeJid, ensureDir, formatUptime } = require('./helper/utils');
const { logInfo, logSuccess, logWarn, logError, logSession } = require('./helper/logger');

// ─────────────────────────────────────────────────────────────
//   GLOBALS & DATABASE
// ─────────────────────────────────────────────────────────────

global.botStartTime = Date.now();
ensureDir(settings.SESSION_DIR);
ensureDir('./database');

const DB_PATH = path.join(__dirname, 'database', 'database.json');
let db = { users: {}, chats: {}, settings: {}, erpg: {} };

function loadDb() {
  try {
    if (fs.existsSync(DB_PATH)) {
      const data = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
      db = { ...db, ...data };
    }
  } catch (e) { logError('DB', 'Failed to load database: ' + e.message); }
}
function saveDb() {
  try { fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2)); } catch (e) { logError('DB', 'Failed to save: ' + e.message); }
}
loadDb();

// ─────────────────────────────────────────────────────────────
//   STYLE HELPERS (formatSimpleReply & formatBoxReply)
// ─────────────────────────────────────────────────────────────

function formatSimpleReply(title, content) {
  return `❐  ⌜${title}⌟  ❐\n┃➥ ${content}\n┗❐`;
}

function formatBoxReply(title, lines = [], footer = '') {
  let box = `❐  ⌜${title}⌟  ❐\n`;
  lines.forEach(line => {
    box += `┃➥ ${line}\n`;
  });
  if (footer) {
    box += `┗❐\n❐  ⌜${footer}⌟  ❐\n`;
  }
  box += `┗❐`;
  return box;
}

// ─────────────────────────────────────────────────────────────
//   PAYSTACK HELPERS
// ─────────────────────────────────────────────────────────────

const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY || settings.PAYSTACK_SECRET_KEY;
const PAYSTACK_PUBLIC = process.env.PAYSTACK_PUBLIC_KEY || settings.PAYSTACK_PUBLIC_KEY;

async function initPaystackPayment(amount, email, reference, metadata = {}) {
  try {
    const response = await axios.post(
      'https://api.paystack.co/transaction/initialize',
      {
        amount: amount * 100,
        email: email || 'user@example.com',
        reference: reference || `PAY-${Date.now()}`,
        metadata: metadata,
        callback_url: process.env.PAYSTACK_CALLBACK_URL || settings.PAYSTACK_CALLBACK_URL || '',
      },
      {
        headers: { Authorization: `Bearer ${PAYSTACK_SECRET}`, 'Content-Type': 'application/json' },
        timeout: 10000,
      }
    );
    return response.data;
  } catch (err) {
    console.error('Paystack init error:', err.response?.data || err.message);
    return null;
  }
}

async function verifyPaystackPayment(reference) {
  try {
    const response = await axios.get(
      `https://api.paystack.co/transaction/verify/${reference}`,
      {
        headers: { Authorization: `Bearer ${PAYSTACK_SECRET}` },
        timeout: 10000,
      }
    );
    return response.data;
  } catch (err) {
    console.error('Paystack verify error:', err.response?.data || err.message);
    return null;
  }
}

// ─────────────────────────────────────────────────────────────
//   PANEL CREATION (PTERODACTYL) – with dynamic egg variables
// ─────────────────────────────────────────────────────────────

const PANEL_DOMAIN = process.env.PANEL_DOMAIN || settings.PANEL_DOMAIN || 'https://sky.blacklord.tech';
const PANEL_APIKEY = process.env.PANEL_APIKEY || settings.PANEL_APIKEY || 'ptla_0yvCKoqhiMpsXwbA2XDn7VsUJTGvVfLRo8UznRsCR0s';
const PANEL_EGG   = parseInt(process.env.PANEL_EGG   || settings.PANEL_EGG   || 15);
const PANEL_NEST  = parseInt(process.env.PANEL_NEST  || settings.PANEL_NEST  || 5);
const PANEL_LOC   = parseInt(process.env.PANEL_LOC   || settings.PANEL_LOC   || 1);

function generatePassword(username) {
  const first = username.charAt(0).toUpperCase();
  const rest = username.slice(1).toLowerCase();
  const digits = String(Math.floor(Math.random() * 90 + 10));
  return first + rest + digits + '!';
}

async function createPterodactylPanel(username, ramMB, diskMB, cpuPercent, isAdmin = false) {
  const email = `${username}@gmail.com`;
  const password = generatePassword(username);

  // 1. Create user
  let userId;
  try {
    const userRes = await axios.post(
      `${PANEL_DOMAIN}/api/application/users`,
      {
        email,
        username,
        first_name: username,
        last_name: isAdmin ? 'Admin' : 'Panel',
        root_admin: isAdmin,
        language: 'en',
        password,
      },
      {
        headers: { Authorization: `Bearer ${PANEL_APIKEY}`, 'Content-Type': 'application/json' },
        timeout: 15000,
      }
    );
    userId = userRes.data.attributes.id;
  } catch (e) {
    throw new Error(`User creation failed: ${e.response?.data?.errors?.[0]?.detail || e.message}`);
  }

  // 2. Get an available allocation
  let allocId;
  try {
    const allocRes = await axios.get(
      `${PANEL_DOMAIN}/api/application/nodes/${PANEL_LOC}/allocations`,
      {
        headers: { Authorization: `Bearer ${PANEL_APIKEY}` },
        timeout: 15000,
      }
    );
    const alloc = allocRes.data.data.find(a => a.attributes.assigned === false);
    if (!alloc) throw new Error('No available port');
    allocId = alloc.attributes.id;
  } catch (e) {
    throw new Error(`Allocation error: ${e.message}`);
  }

  // 3. Fetch egg details to get required environment variables
  let eggDetails;
  try {
    const eggRes = await axios.get(
      `${PANEL_DOMAIN}/api/application/nests/${PANEL_NEST}/eggs/${PANEL_EGG}?include=variables`,
      {
        headers: { Authorization: `Bearer ${PANEL_APIKEY}` },
        timeout: 15000,
      }
    );
    eggDetails = eggRes.data.attributes;
  } catch (e) {
    throw new Error(`Failed to fetch egg details: ${e.message}`);
  }

  // 4. Build environment object with defaults from the egg
  const environment = {};
  if (eggDetails.relationships && eggDetails.relationships.variables && eggDetails.relationships.variables.data) {
    for (const varData of eggDetails.relationships.variables.data) {
      const varAttr = varData.attributes || varData;
      const key = varAttr.env_variable;
      if (key) {
        environment[key] = varAttr.default_value || '';
      }
    }
  }
  // Override with our standard values
  environment.NODE_VERSION = '18';
  environment.INST = 'npm';
  environment.CMD_RUN = 'npm start';
  if (typeof environment.AUTO_UPDATE !== 'undefined') {
    environment.AUTO_UPDATE = '0';
  }

  // 5. Create server
  try {
    const serverData = {
      name: `${username}-${isAdmin ? 'admin' : 'panel'}`,
      user: userId,
      egg: PANEL_EGG,
      docker_image: eggDetails.docker_image || 'ghcr.io/parkervcp/yolks:nodejs_18',
      startup: eggDetails.startup || 'npm start',
      environment: environment,
      skip_scripts: false,
      limits: { memory: ramMB, swap: 0, disk: diskMB, io: 500, cpu: cpuPercent },
      feature_limits: { databases: 1, backups: 1 },
      allocation: { default: allocId },
      deployment: { locations: [PANEL_LOC] },
      start_on_completion: true,
    };

    const srvRes = await axios.post(
      `${PANEL_DOMAIN}/api/application/servers`,
      serverData,
      {
        headers: { Authorization: `Bearer ${PANEL_APIKEY}`, 'Content-Type': 'application/json' },
        timeout: 30000,
      }
    );

    return {
      success: true,
      username,
      password,
      panelDomain: PANEL_DOMAIN,
      serverId: srvRes.data.attributes.id,
      ram: ramMB,
      disk: diskMB,
      cpu: cpuPercent,
      isAdmin,
    };
  } catch (e) {
    const errorMsg = e.response?.data?.errors?.[0]?.detail || e.message;
    throw new Error(`Server creation failed: ${errorMsg}`);
  }
}

// ─────────────────────────────────────────────────────────────
//   PENDING PAYMENTS STORE
// ─────────────────────────────────────────────────────────────

const pendingPayments = new Map();
global.pendingPayments = pendingPayments;

// ─────────────────────────────────────────────────────────────
//   PERSISTENT PENDING REPLIES (survives restarts)
// ─────────────────────────────────────────────────────────────

const PENDING_FILE  = './database/pendingReplies.json';
const PREMIUM_FILE  = './database/prem_data.json';

function loadJSON(file, def) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return def; }
}
function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

let pendingRepliesData = loadJSON(PENDING_FILE, {});
const pendingReplies   = new Map(Object.entries(pendingRepliesData));

function savePendingReplies() {
  saveJSON(PENDING_FILE, Object.fromEntries(pendingReplies));
}

// ─────────────────────────────────────────────────────────────
//   PREMIUM SYSTEM
// ─────────────────────────────────────────────────────────────

const _rp = loadJSON(PREMIUM_FILE, {});
let premData = {
  premOnly: !!_rp.premOnly,
  owners: Array.isArray(_rp.owners) ? _rp.owners : [],
  premUsers: Array.isArray(_rp.premUsers) ? _rp.premUsers : [],
};

function savePrem() { saveJSON(PREMIUM_FILE, premData); }

function isOwner(id) {
  return String(id) === String(settings.OWNER_TELEGRAM_ID) || premData.owners.includes(String(id));
}
function isPremium(id) {
  return isOwner(id) || premData.premUsers.includes(String(id));
}
function canUseBot(id) {
  if (!premData.premOnly) return true;
  return isPremium(id);
}

// ─────────────────────────────────────────────────────────────
//   ACTIVE SOCKETS
// ─────────────────────────────────────────────────────────────

const activeSockets      = new Map();
const notifiedConnected  = new Set();
global._activeSockets    = activeSockets;

// ─────────────────────────────────────────────────────────────
//   GITHUB SESSION SYNC (optional – keep if you use it)
// ─────────────────────────────────────────────────────────────

const GH_TOKEN  = settings.GITHUB_TOKEN  || process.env.GITHUB_TOKEN;
const GH_USER   = settings.GITHUB_USERNAME || process.env.GITHUB_USERNAME;
const GH_REPO   = settings.GITHUB_REPO   || process.env.GITHUB_REPO;
const GH_BRANCH = settings.GITHUB_BRANCH || process.env.GITHUB_BRANCH || 'main';

function ghRequest(method, urlPath, body = null) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const opts = {
      hostname: 'api.github.com',
      path: `/repos/${GH_USER}/${GH_REPO}/contents/${urlPath}?ref=${GH_BRANCH}`,
      method,
      headers: {
        'Authorization': `Bearer ${GH_TOKEN}`,
        'User-Agent': 'Samsung-MD',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        ...(data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {}),
      },
    };
    const req = https.request(opts, (res) => {
      let raw = '';
      res.on('data', c => raw += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(raw) }); }
        catch { resolve({ status: res.statusCode, body: raw }); }
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function ghListDir(remotePath) {
  const { status, body } = await ghRequest('GET', remotePath);
  if (status !== 200 || !Array.isArray(body)) return [];
  return body;
}

async function ghGetFile(remotePath) {
  const { status, body } = await ghRequest('GET', remotePath);
  if (status !== 200 || !body.content) return null;
  return { content: Buffer.from(body.content.replace(/\n/g, ''), 'base64'), sha: body.sha };
}

async function ghDeleteFile(remotePath, sha, message) {
  return ghRequest('DELETE', remotePath, { message, sha });
}

async function downloadSessionFromGitHub(sessionId) {
  try {
    const remotePath = `sessions/${sessionId}`;
    const files = await ghListDir(remotePath);
    if (!files.length) return false;
    const localDir = sessionDir(sessionId);
    ensureDir(localDir);
    for (const f of files) {
      if (f.type !== 'file') continue;
      const fileData = await ghGetFile(`${remotePath}/${f.name}`);
      if (!fileData) continue;
      fs.writeFileSync(path.join(localDir, f.name), fileData.content);
      logInfo('GH-SYNC', `Downloaded: ${sessionId}/${f.name}`);
    }
    return true;
  } catch (e) {
    logError('GH-SYNC', `Download failed for ${sessionId}: ${e.message}`);
    return false;
  }
}

async function deleteSessionFromGitHub(sessionId) {
  try {
    const files = await ghListDir(`sessions/${sessionId}`);
    for (const f of files) {
      if (f.type === 'file') await ghDeleteFile(`sessions/${sessionId}/${f.name}`, f.sha, `Logout cleanup: ${sessionId}`);
    }
    logInfo('GH-SYNC', `Deleted from GitHub: ${sessionId}`);
  } catch (e) {
    logError('GH-SYNC', `GH delete failed for ${sessionId}: ${e.message}`);
  }
}

async function syncSessionsFromGitHub() {
  try {
    const { status, body } = await ghRequest('GET', '');
    if (status !== 200 || !Array.isArray(body)) return;
    const sessionIds = new Set();
    for (const item of body) {
      const m = item.path.match(/^sessions\/([^\/]+)\/creds\.json$/);
      if (m) sessionIds.add(m[1]);
    }
    if (!sessionIds.size) { logInfo('GH-SYNC', 'No remote sessions'); return; }
    for (const sid of sessionIds) {
      if (!sessionExists(sid)) {
        logInfo('GH-SYNC', `Downloading: ${sid}`);
        await downloadSessionFromGitHub(sid);
      } else {
        logInfo('GH-SYNC', `Already local: ${sid}`);
      }
    }
  } catch (e) {
    logError('GH-SYNC', `Sync error: ${e.message}`);
  }
}

function startSessionWatcher() {
  setInterval(async () => {
    try {
      const { status, body } = await ghRequest('GET', '');
      if (status !== 200 || !Array.isArray(body)) return;
      const sessionIds = new Set();
      for (const item of body) {
        const m = item.path.match(/^sessions\/([^\/]+)\/creds\.json$/);
        if (m) sessionIds.add(m[1]);
      }
      for (const sid of sessionIds) {
        if (activeSockets.has(sid)) continue;
        if (!sessionExists(sid)) {
          logInfo('WATCHER', `New session detected: ${sid}`);
          await downloadSessionFromGitHub(sid);
        }
        if (sessionExists(sid) && !activeSockets.has(sid)) {
          logInfo('WATCHER', `Starting: ${sid}`);
          let tgUserId = null;
          const allPairs = getAllPairs();
          for (const [uid, pairs] of Object.entries(allPairs)) {
            if (pairs.find(p => p.sessionId === sid)) { tgUserId = uid; break; }
          }
          notifiedConnected.add(sid);
          startWhatsApp(sid, null, null, tgUserId).catch(e => logError('WATCHER', e.message));
        }
      }
    } catch {}
  }, 1000);
  logSuccess('WATCHER', 'Live session watcher started (30s interval)');
}

// ─────────────────────────────────────────────────────────────
//   SELF-PING
// ─────────────────────────────────────────────────────────────

function startPingLoop() {
  const urls = [settings.PANEL_URL, settings.WEBSITE_URL].filter(Boolean);
  http.createServer((req, res) => {
    const uptime = formatUptime(Date.now() - global.botStartTime);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'alive', uptime, sessions: activeSockets.size }));
  }).listen(process.env.PORT || 3001, () => {
    logSuccess('PING', `Health server :${process.env.PORT || 3001}`);
  });
  setInterval(() => {
    const uptime = formatUptime(Date.now() - global.botStartTime);
    process.stdout.write(chalk.gray(`[UPTIME] ${uptime}\n`));
    for (const url of urls) {
      try {
        const parsed = new URL(url);
        const mod = parsed.protocol === 'https:' ? https : http;
        const req = mod.get(url, res => logInfo('PING', `${url} → ${res.statusCode}`));
        req.on('error', () => {});
        req.setTimeout(8000, () => req.destroy());
      } catch {}
    }
  }, 4 * 60 * 1000);
}

// ─────────────────────────────────────────────────────────────
//   TELEGRAM BOT  –  Full Integration
// ─────────────────────────────────────────────────────────────

const bot = new Telegraf(settings.TELEGRAM_TOKEN);

// ── /start ────────────────────────────────────────────────────
bot.start(async (ctx) => {
  registerUser(ctx.from.id, ctx.from.first_name);
  const allUsers   = Object.keys(getAllUsers()).length;
  const myPairs    = getUserPairs(ctx.from.id);
  const activeMine = myPairs.filter(p => activeSockets.has(p.sessionId)).length;
  const uptime     = formatUptime(Date.now() - global.botStartTime);
  const premStatus = premData.premOnly ? '🔒 Premium Only' : '🌐 Public';

  const text =
`
  •━═〘 𝗦Λ𝗠𝗦𝗨𝗡𝗚 𝗫𝗠𝗗 〙═━•

╭═━⪩ 〘 SYSTEM INFO 〙•━•
│⫹⫺ 𝗕𝗢𝗧:〘 𝗦Λ𝗠𝗦𝗨𝗡𝗚 𝗫𝗠𝗗 🟢 〙
│⫹⫺ 𝗗𝗘𝗩: 𝑼𝒍𝒕𝒓𝒂 𝒊𝒏𝒇𝒊𝒏𝒊𝒕𝒚
│⫹⫺ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡: 𝐕𝐈𝐒𝐈𝐎𝐍 𝟐.𝟎
│⫹⫺ 𝗠𝗢𝗗𝗘: public
│⫹⫺ 𝗣𝗟𝗔𝗧𝗙𝗢𝗥𝗠: 𝒍𝒊𝒏𝒖𝒙
│⫹⫺ 𝗨𝗣𝗧𝗜𝗠𝗘: ${uptime}
│⫹⫺ 𝗢𝗪𝗡𝗘𝗥: ⃝⃪ 𝑺𝒂𝒎𝒔𝒖𝒏𝒈 
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━•

╭━━•›〘 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦 〙•━•
│⌬ /pair <number>
│⌬ /delpair <number>
│⌬ /listpaired
│⌬ /reportissue <msg>
│⌬ /listsession
│⌬ /broadcast
│⌬ /premonly
│⌬ /addprem <id>
│⌬ /delprem <id>
│⌬ /listprem
│⌬ /addowner <id>
│⌬ /buypanel <username>
│⌬ /cpanel <username>
│⌬ /verifypayment [reference]
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•

⌬ 〘 𝗦Λ𝗠𝗦𝗨𝗡𝗚 𝗫𝗠𝗗 🟢 〙`;

  const inlineKeyboard = Markup.inlineKeyboard([
    [Markup.button.callback('📦 Buy Panel', 'buypanel_help')],
    [Markup.button.callback('👑 Admin Panel', 'cpanel_help')],
    [Markup.button.callback('🔗 Pair WhatsApp', 'pair_help')],
    [Markup.button.callback('💳 Verify Payment', 'verify_help')],
  ]);

  try {
    await ctx.replyWithPhoto(
      { url: 'https://i.ibb.co/m5JpCbLS/527014e4cc70.jpg' },
      { caption: text, parse_mode: 'Markdown', ...inlineKeyboard }
    );
  } catch {
    await ctx.reply(text, { parse_mode: 'Markdown', ...inlineKeyboard });
  }
});

// ── Help actions ──
bot.action('buypanel_help', async (ctx) => {
  await ctx.answerCbQuery();
  await ctx.reply(
    formatSimpleReply('📦 BUY PANEL', 'Usage: /buypanel <username>\nExample: /buypanel kamau\n\nThen choose RAM from the buttons.'),
    { parse_mode: 'Markdown' }
  );
});

bot.action('cpanel_help', async (ctx) => {
  await ctx.answerCbQuery();
  await ctx.reply(
    formatSimpleReply('👑 ADMIN PANEL', 'Usage: /cpanel <username>\nExample: /cpanel adminuser\n\nCreates a panel with full admin access.'),
    { parse_mode: 'Markdown' }
  );
});

bot.action('pair_help', async (ctx) => {
  await ctx.answerCbQuery();
  await ctx.reply(
    formatSimpleReply('🔗 PAIR WHATSAPP', 'Usage: /pair <phone>\nExample: /pair 254704955033'),
    { parse_mode: 'Markdown' }
  );
});

bot.action('verify_help', async (ctx) => {
  await ctx.answerCbQuery();
  await ctx.reply(
    formatSimpleReply('💳 VERIFY PAYMENT', 'Usage: /verifypayment [reference]\nIf no reference is provided, it will auto‑detect your pending payment.'),
    { parse_mode: 'Markdown' }
  );
});

// ─────────────────────────────────────────────────────────────
//   PANEL PURCHASE – TELEGRAM COMMANDS
// ─────────────────────────────────────────────────────────────

const ramMap = {
  '1gb': { ram: 1024, disk: 1024, cpu: 40, price: 1, isAdmin: false },
  '2gb': { ram: 2048, disk: 2048, cpu: 60, price: 2, isAdmin: false },
  '3gb': { ram: 3072, disk: 3072, cpu: 80, price: 3, isAdmin: false },
  '4gb': { ram: 4096, disk: 4096, cpu: 100, price: 4, isAdmin: false },
  'unlimited': { ram: 0, disk: 0, cpu: 0, price: 8, isAdmin: false },
  'cpanel': { ram: 1024, disk: 1024, cpu: 40, price: 10, isAdmin: true },
};

bot.command('buypanel', async (ctx) => {
  registerUser(ctx.from.id, ctx.from.first_name);
  if (!canUseBot(ctx.from.id)) {
    return ctx.reply(
      formatSimpleReply('🔒 PREMIUM ONLY', 'Bot is in premium-only mode. Contact owner to get access.'),
      { parse_mode: 'Markdown' }
    );
  }

  const args = ctx.message.text.split(/\s+/);
  const username = args[1];

  if (!username) {
    await ctx.reply(
      formatSimpleReply('📦 BUY PANEL', 'Please provide a username:\n/buypanel <username>\nExample: /buypanel kamau'),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  const cleanUsername = username.toLowerCase().replace(/[^a-z0-9_-]/g, '');
  if (!cleanUsername || cleanUsername.length < 3) {
    await ctx.reply(
      formatSimpleReply('❌ INVALID', 'Username must be at least 3 characters (letters, numbers, underscore).'),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  const sessionKey = `tg_${ctx.from.id}_buypanel`;
  if (!global._pendingTelegram) global._pendingTelegram = {};
  global._pendingTelegram[sessionKey] = { username: cleanUsername, isAdmin: false };

  const ramButtons = [
    [Markup.button.callback('1GB - $1', 'panel_ram_1gb')],
    [Markup.button.callback('2GB - $2', 'panel_ram_2gb')],
    [Markup.button.callback('3GB - $3', 'panel_ram_3gb')],
    [Markup.button.callback('4GB - $4', 'panel_ram_4gb')],
    [Markup.button.callback('Unlimited - $8', 'panel_ram_unlimited')],
    [Markup.button.callback('cPanel - $10', 'panel_ram_cpanel')],
    [Markup.button.callback('❌ Cancel', 'panel_cancel')],
  ];

  await ctx.reply(
    formatBoxReply(
      '🖥️ PANEL PURCHASE',
      [
        `Username : ${cleanUsername}`,
        `Type : Standard Panel`,
        `\nSelect RAM:`
      ],
      'SELECT'
    ),
    { parse_mode: 'Markdown', ...Markup.inlineKeyboard(ramButtons) }
  );
});

bot.command('cpanel', async (ctx) => {
  registerUser(ctx.from.id, ctx.from.first_name);
  if (!canUseBot(ctx.from.id)) {
    return ctx.reply(
      formatSimpleReply('🔒 PREMIUM ONLY', 'Bot is in premium-only mode. Contact owner to get access.'),
      { parse_mode: 'Markdown' }
    );
  }

  const args = ctx.message.text.split(/\s+/);
  const username = args[1];

  if (!username) {
    await ctx.reply(
      formatSimpleReply('👑 ADMIN PANEL', 'Please provide a username:\n/cpanel <username>\nExample: /cpanel adminuser'),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  const cleanUsername = username.toLowerCase().replace(/[^a-z0-9_-]/g, '');
  if (!cleanUsername || cleanUsername.length < 3) {
    await ctx.reply(
      formatSimpleReply('❌ INVALID', 'Username must be at least 3 characters (letters, numbers, underscore).'),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  const sessionKey = `tg_${ctx.from.id}_cpanel`;
  if (!global._pendingTelegram) global._pendingTelegram = {};
  global._pendingTelegram[sessionKey] = { username: cleanUsername, isAdmin: true };

  const ramButtons = [
    [Markup.button.callback('1GB - $1', 'panel_ram_1gb')],
    [Markup.button.callback('2GB - $2', 'panel_ram_2gb')],
    [Markup.button.callback('3GB - $3', 'panel_ram_3gb')],
    [Markup.button.callback('4GB - $4', 'panel_ram_4gb')],
    [Markup.button.callback('Unlimited - $8', 'panel_ram_unlimited')],
    [Markup.button.callback('cPanel - $10', 'panel_ram_cpanel')],
    [Markup.button.callback('❌ Cancel', 'panel_cancel')],
  ];

  await ctx.reply(
    formatBoxReply(
      '👑 ADMIN PANEL PURCHASE',
      [
        `Username : ${cleanUsername}`,
        `Type : Admin Panel (full access)`,
        `\nSelect RAM:`
      ],
      'SELECT'
    ),
    { parse_mode: 'Markdown', ...Markup.inlineKeyboard(ramButtons) }
  );
});

// ── RAM selection callback ──
bot.action(/panel_ram_(.+)/, async (ctx) => {
  await ctx.answerCbQuery();
  const ramKey = ctx.match[1];

  const tgId = ctx.from.id;
  let sessionKey = `tg_${tgId}_buypanel`;
  let pending = global._pendingTelegram?.[sessionKey];

  if (!pending) {
    sessionKey = `tg_${tgId}_cpanel`;
    pending = global._pendingTelegram?.[sessionKey];
  }

  if (!pending || !pending.username) {
    await ctx.reply(
      formatSimpleReply('❌ SESSION EXPIRED', 'No active session. Please start again with /buypanel or /cpanel.'),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  const spec = ramMap[ramKey];
  if (!spec) {
    await ctx.reply(
      formatSimpleReply('❌ INVALID', 'Invalid RAM option.'),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  const { username, isAdmin } = pending;
  delete global._pendingTelegram[sessionKey];

  const amount = spec.price;
  const reference = `${isAdmin ? 'CPANEL' : 'PANEL'}-${tgId}-${Date.now()}`;
  const email = `${tgId}@telegram.bot`;
  const metadata = {
    user_id: tgId,
    username,
    ram: spec.ram,
    disk: spec.disk,
    cpu: spec.cpu,
    price: spec.price,
    isAdmin: spec.isAdmin,
  };

  const init = await initPaystackPayment(amount, email, reference, metadata);
  if (!init || !init.status) {
    await ctx.reply(
      formatSimpleReply('❌ PAYMENT FAILED', 'Failed to create payment. Please try again.'),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  const paymentUrl = init.data.authorization_url;
  pendingPayments.set(reference, {
    userId: tgId,
    username,
    ram: spec.ram,
    disk: spec.disk,
    cpu: spec.cpu,
    price: spec.price,
    isAdmin: spec.isAdmin,
    status: 'pending',
  });

  const typeLabel = isAdmin ? '👑 CPANEL' : '📦 ' + (spec.ram === 0 ? 'Unlimited' : `${spec.disk/1024}GB`) + ' Panel';
  const ramDisplay = spec.ram === 0 ? 'Unlimited' : `${spec.ram}MB`;
  const diskDisplay = spec.disk === 0 ? 'Unlimited' : `${spec.disk}MB`;
  const cpuDisplay = spec.cpu === 0 ? 'Unlimited' : `${spec.cpu}%`;

  // ── Main payment message with verify button ──
  const verifyButton = Markup.inlineKeyboard([
    [Markup.button.callback('✅ Verify Payment', `verify_panel_payment_${reference}`)]
  ]);

  await ctx.reply(
    formatBoxReply(
      '💳 COMPLETE YOUR PAYMENT',
      [
        `Type : ${typeLabel}`,
        `Username : ${username}`,
        `📊 RAM : ${ramDisplay}`,
        `💾 Disk : ${diskDisplay}`,
        `⚡ CPU : ${cpuDisplay}`,
        `💰 Price : $${spec.price}`,
        ``,
        `🔗 Pay here :`,
        `${paymentUrl}`,
        ``,
        `After paying, tap the button below to verify.`
      ],
      'PAYMENT'
    ),
    { parse_mode: 'Markdown', ...verifyButton }
  );

  // ── Separate reference message ──
  await ctx.reply(
    formatBoxReply(
      '📋 YOUR REFERENCE',
      [
        `\`${reference}\``,
        ``,
        `You can also use this reference with:`,
        `/verifypayment ${reference}`
      ],
      'REFERENCE'
    ),
    { parse_mode: 'Markdown' }
  );
});

bot.action('panel_cancel', async (ctx) => {
  await ctx.answerCbQuery();
  const tgId = ctx.from.id;
  delete global._pendingTelegram?.[`tg_${tgId}_buypanel`];
  delete global._pendingTelegram?.[`tg_${tgId}_cpanel`];
  await ctx.reply(
    formatSimpleReply('❌ CANCELLED', 'Panel purchase cancelled.'),
    { parse_mode: 'Markdown' }
  );
});

// ─────────────────────────────────────────────────────────────
//   VERIFY PAYMENT – Button and Command
// ─────────────────────────────────────────────────────────────

// ── Verify button action ──
bot.action(/verify_panel_payment_(.+)/, async (ctx) => {
  await ctx.answerCbQuery();
  const reference = ctx.match[1];

  const pending = pendingPayments.get(reference);
  if (!pending) {
    await ctx.reply(
      formatSimpleReply('❌ NOT FOUND', 'Payment reference not found.'),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  // Use the existing verifyAndCreatePanel helper
  await verifyAndCreatePanel(ctx, reference, pending);
});

// ── Helper to verify and create panel ──
async function verifyAndCreatePanel(ctx, reference, pending) {
  if (pending.status === 'success') {
    await ctx.reply(
      formatSimpleReply('✅ ALREADY VERIFIED', 'This payment was already verified and processed.'),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  await ctx.reply('⏳ Verifying payment...');

  const verify = await verifyPaystackPayment(reference);
  if (!verify || !verify.status) {
    await ctx.reply(
      formatSimpleReply('❌ VERIFICATION FAILED', 'Verification failed. Please try again later.'),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  const data = verify.data;
  if (data.status === 'success') {
    pending.status = 'success';
    const { username, ram, disk, cpu, isAdmin } = pending;

    try {
      const panelResult = await createPterodactylPanel(username, ram, disk, cpu, isAdmin || false);
      const typeLabel = isAdmin ? '👑 CPANEL' : '📦 ' + (ram === 0 ? 'Unlimited' : `${disk/1024}GB`) + ' Panel';
      const ramDisplay = ram === 0 ? 'Unlimited' : `${ram}MB`;
      const diskDisplay = disk === 0 ? 'Unlimited' : `${disk}MB`;
      const cpuDisplay = cpu === 0 ? 'Unlimited' : `${cpu}%`;

      await ctx.reply(
        formatBoxReply(
          '✅ PANEL CREATED SUCCESSFULLY',
          [
            `Type : ${typeLabel}`,
            `👤 Username : ${panelResult.username}`,
            `🔑 Password : ${panelResult.password}`,
            `📊 RAM : ${ramDisplay}`,
            `💾 Disk : ${diskDisplay}`,
            `⚡ CPU : ${cpuDisplay}`,
            `🔗 Login : ${panelResult.panelDomain}`,
            ``,
            `⚠️ Save these credentials!`
          ],
          'COMPLETE'
        ),
        { parse_mode: 'Markdown' }
      );
      pendingPayments.delete(reference);
    } catch (e) {
      await ctx.reply(
        formatSimpleReply('❌ PANEL CREATION FAILED', e.message),
        { parse_mode: 'Markdown' }
      );
    }
  } else {
    await ctx.reply(
      formatBoxReply(
        '⏳ PAYMENT PENDING',
        [
          `Status : ${data.status}`,
          `Please complete the payment and try again.`
        ],
        'AWAITING'
      ),
      { parse_mode: 'Markdown' }
    );
  }
}

// ── /verifypayment command (with/without reference) ──
bot.command('verifypayment', async (ctx) => {
  const args = ctx.message.text.split(/\s+/);
  const providedRef = args[1] ? args[1].trim() : null;

  // If user provided a reference, use it directly
  if (providedRef) {
    const pending = pendingPayments.get(providedRef);
    if (!pending) {
      await ctx.reply(
        formatSimpleReply('❌ NOT FOUND', 'Payment reference not found. Please check and try again.'),
        { parse_mode: 'Markdown' }
      );
      return;
    }
    await verifyAndCreatePanel(ctx, providedRef, pending);
    return;
  }

  // No reference – find user's pending payments
  const tgId = String(ctx.from.id);
  const pendingEntries = Array.from(pendingPayments.entries())
    .filter(([ref, data]) => data.userId === tgId && data.status === 'pending');

  if (pendingEntries.length === 0) {
    await ctx.reply(
      formatBoxReply(
        '❌ NO PENDING PAYMENTS',
        [
          `No pending payments found for your account.`,
          ``,
          `If you already paid, please provide the reference manually:`,
          `/verifypayment <reference>`,
          ``,
          `Example: /verifypayment PANEL-8227524972-1784578496578`,
          ``,
          `You can find the reference in the payment message sent by the bot.`
        ],
        'HELP'
      ),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  // Use the most recent pending payment
  const latest = pendingEntries[pendingEntries.length - 1];
  const reference = latest[0];
  const pending = latest[1];

  await verifyAndCreatePanel(ctx, reference, pending);
});

// ─────────────────────────────────────────────────────────────
//   LIST PENDING PAYMENTS  (debug helper)
// ─────────────────────────────────────────────────────────────

bot.command('listpending', async (ctx) => {
  const tgId = String(ctx.from.id);
  const entries = Array.from(pendingPayments.entries())
    .filter(([ref, data]) => data.userId === tgId && data.status === 'pending');

  if (entries.length === 0) {
    await ctx.reply(
      formatSimpleReply('📭 EMPTY', 'No pending payments.'),
      { parse_mode: 'Markdown' }
    );
    return;
  }

  let msg = '📋 *Your pending payments:*\n\n';
  entries.forEach(([ref, data]) => {
    msg += `🔹 Reference: \`${ref}\`\n`;
    msg += `   Username: ${data.username}\n`;
    msg += `   Type: ${data.isAdmin ? 'Admin' : 'Standard'}\n`;
    msg += `   Price: $${data.price}\n\n`;
  });

  await ctx.reply(msg, { parse_mode: 'Markdown' });
});

// ─────────────────────────────────────────────────────────────
//   PREMIUM COMMANDS (owner only)
// ─────────────────────────────────────────────────────────────

bot.command('premonly', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('❌ Owner only.');
  premData.premOnly = !premData.premOnly;
  savePrem();
  await ctx.reply(
    premData.premOnly
      ? '🔒 *Premium-only mode ON* – only premium users & owners can pair.'
      : '🌐 *Premium-only mode OFF* – all users can pair.',
    { parse_mode: 'Markdown' }
  );
});

bot.command('addprem', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('❌ Owner only.');
  const target = ctx.message.text.split(/\s+/)[1];
  if (!target) return ctx.reply('Usage: /addprem <telegram_id>');
  if (premData.premUsers.includes(target)) return ctx.reply(`ℹ️ ${target} is already premium.`);
  premData.premUsers.push(target);
  savePrem();
  await ctx.reply(`✅ Added *${target}* as premium user.`, { parse_mode: 'Markdown' });
});

bot.command('delprem', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('❌ Owner only.');
  const target = ctx.message.text.split(/\s+/)[1];
  if (!target) return ctx.reply('Usage: /delprem <telegram_id>');
  const idx = premData.premUsers.indexOf(target);
  if (idx === -1) return ctx.reply(`ℹ️ ${target} is not premium.`);
  premData.premUsers.splice(idx, 1);
  savePrem();
  await ctx.reply(`🗑 Removed *${target}* from premium.`, { parse_mode: 'Markdown' });
});

bot.command('listprem', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('❌ Owner only.');
  const mode    = premData.premOnly ? '🔒 Premium-only ON' : '🌐 Premium-only OFF';
  const owners  = [String(settings.OWNER_TELEGRAM_ID), ...premData.owners].join('\n') || 'none';
  const prems   = premData.premUsers.join('\n') || 'none';
  await ctx.reply(
    `*Premium Status*\n${mode}\n\n*Owners:*\n${owners}\n\n*Premium Users:*\n${prems}`,
    { parse_mode: 'Markdown' }
  );
});

bot.command('addowner', async (ctx) => {
  if (String(ctx.from.id) !== String(settings.OWNER_TELEGRAM_ID)) return ctx.reply('❌ Main owner only.');
  const target = ctx.message.text.split(/\s+/)[1];
  if (!target) return ctx.reply('Usage: /addowner <telegram_id>');
  if (premData.owners.includes(target)) return ctx.reply(`ℹ️ ${target} is already an owner.`);
  premData.owners.push(target);
  savePrem();
  await ctx.reply(`✅ Promoted *${target}* to owner.`, { parse_mode: 'Markdown' });
});

// ─────────────────────────────────────────────────────────────
//   PAIRING COMMANDS
// ─────────────────────────────────────────────────────────────

bot.command('pair', async (ctx) => {
  registerUser(ctx.from.id, ctx.from.first_name);
  if (!canUseBot(ctx.from.id)) {
    return ctx.reply('🔒 *Bot is in premium-only mode.*\nContact the owner to get access.', { parse_mode: 'Markdown' });
  }
  const phone = ctx.message.text.split(/\s+/)[1]?.replace(/\D/g, '');
  if (!phone || phone.length < 7) {
    return ctx.reply('Usage: `/pair 254704955033`', { parse_mode: 'Markdown' });
  }
  const uid       = String(ctx.from.id);
  const sessionId = `wa_${uid}_${phone}`;
  if (activeSockets.has(sessionId)) {
    return ctx.reply(`✅ +${phone} already connected!\nUse /delpair ${phone} to disconnect.`);
  }
  if (sessionExists(sessionId)) {
    await ctx.reply(`♻️ Reconnecting +${phone}...`);
    await startWhatsApp(sessionId, ctx.chat.id, null, uid);
    return;
  }
  await ctx.reply(`🔄 Pairing *+${phone}*...`, { parse_mode: 'Markdown' });
  await startWhatsApp(sessionId, ctx.chat.id, phone, uid);
});

bot.command('delpair', async (ctx) => {
  const phone = ctx.message.text.split(/\s+/)[1]?.replace(/\D/g, '');
  if (!phone) return ctx.reply('Usage: /delpair 254704955033');
  const uid       = String(ctx.from.id);
  const sessionId = `wa_${uid}_${phone}`;
  const sock = activeSockets.get(sessionId);
  if (sock) {
    try { await sock.logout(); } catch {}
    try { sock.ws?.close(); } catch {}
    activeSockets.delete(sessionId);
  }
  notifiedConnected.delete(sessionId);
  removePair(uid, sessionId);
  const ok = deleteSession(sessionId);
  deleteSessionFromGitHub(sessionId).catch(() => {});
  await ctx.reply(ok
    ? `🗑 +${phone} deleted. Use /pair ${phone} to reconnect.`
    : `ℹ️ No session found for +${phone}.`
  );
});

bot.command('listpaired', async (ctx) => {
  const pairs = getUserPairs(String(ctx.from.id));
  if (!pairs.length) return ctx.reply('No paired numbers. Use /pair <number>');
  const list = pairs.map((p, i) => `${i+1}. +${p.waNum} ${activeSockets.has(p.sessionId) ? '🟢' : '🔴'}`).join('\n');
  await ctx.reply(`📱 *Your numbers (${pairs.length}):*\n\n${list}`, { parse_mode: 'Markdown' });
});

bot.command('listsession', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('❌ Owner only.');
  const list = listSessions();
  if (!list.length) return ctx.reply('No sessions.');
  const text = list.map((s, i) => `${i+1}. \`${s}\` ${activeSockets.has(s) ? '🟢' : '🔴'}`).join('\n');
  await ctx.reply(`📋 *Sessions (${list.length})*\n\n${text}`, { parse_mode: 'Markdown' });
});

// ─────────────────────────────────────────────────────────────
//   BROADCAST
// ─────────────────────────────────────────────────────────────

const broadcastPending = new Set();

function parseBroadcastButtons(text) {
  if (!text) return { clean: text || '', markup: null };
  const btnRegex = /\[([^\]|]+)\|([^\]]+)\]/g;
  const rows = [];
  let currentRow = [];
  let clean = text;
  let match;
  const matches = [];
  while ((match = btnRegex.exec(text)) !== null) matches.push(match);
  if (!matches.length) return { clean: text, markup: null };
  for (let i = 0; i < matches.length; i++) {
    const m      = matches[i];
    const label  = m[1].trim();
    const url    = m[2].trim();
    const before = i === 0 ? text.slice(0, m.index) : text.slice(matches[i-1].index + matches[i-1][0].length, m.index);
    if (i > 0 && before.includes('\n')) { if (currentRow.length) rows.push(currentRow); currentRow = []; }
    currentRow.push(Markup.button.url(label, url));
  }
  if (currentRow.length) rows.push(currentRow);
  clean = text.replace(/\[([^\]|]+)\|([^\]]+)\]/g, '').replace(/\n{3,}/g, '\n\n').trim();
  return { clean, markup: rows.length ? Markup.inlineKeyboard(rows) : null };
}

async function sendBroadcastToUser(uid, msg) {
  const tg      = bot.telegram;
  const rawText = msg.text || msg.caption || '';
  const { clean, markup } = parseBroadcastButtons(rawText);
  const extra   = { parse_mode: 'Markdown', ...(markup || {}) };
  if (msg.sticker)    return tg.sendSticker(uid, msg.sticker.file_id, markup ? { reply_markup: markup.reply_markup } : {});
  if (msg.animation)  return tg.sendAnimation(uid, msg.animation.file_id, { caption: clean, ...extra });
  if (msg.video_note) return tg.sendVideoNote(uid, msg.video_note.file_id);
  if (msg.voice)      return tg.sendVoice(uid, msg.voice.file_id, { caption: clean, ...extra });
  if (msg.photo) {
    const photo = msg.photo[msg.photo.length - 1];
    return tg.sendPhoto(uid, photo.file_id, { caption: clean, ...extra });
  }
  if (msg.video)    return tg.sendVideo(uid, msg.video.file_id, { caption: clean, ...extra });
  if (msg.audio)    return tg.sendAudio(uid, msg.audio.file_id, { caption: clean, ...extra });
  if (msg.document) return tg.sendDocument(uid, msg.document.file_id, { caption: clean, ...extra });
  if (msg.text)     return tg.sendMessage(uid, clean || msg.text, extra);
  return tg.forwardMessage(uid, msg.chat.id, msg.message_id);
}

bot.command('broadcast', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('❌ Owner only.');
  broadcastPending.add(String(ctx.from.id));
  await ctx.reply(
    `📢 *Broadcast Setup*\n\nNow send the message you want to broadcast.\nSupported: text, photo, video, audio, document, sticker, voice, animation.\n\n*Optional inline buttons* – add to caption/text:\n\`[Button Label | https://url.com]\`\n\nSend /cancel to abort.`,
    { parse_mode: 'Markdown' }
  );
});

bot.command('cancel', async (ctx) => {
  if (broadcastPending.has(String(ctx.from.id))) {
    broadcastPending.delete(String(ctx.from.id));
    return ctx.reply('❌ Broadcast cancelled.');
  }
  return ctx.reply('Nothing to cancel.');
});

bot.on('message', async (ctx, next) => {
  const oid = String(ctx.from?.id);
  if (!broadcastPending.has(oid)) return next();
  broadcastPending.delete(oid);
  const users    = getAllUsers();
  const uids     = Object.keys(users);
  const progress = await ctx.reply(`📤 Broadcasting to ${uids.length} users...`);
  let sent = 0, failed = 0;
  for (const uid of uids) {
    try {
      await sendBroadcastToUser(uid, ctx.message);
      sent++;
    } catch { failed++; }
    await new Promise(r => setTimeout(r, 80));
  }
  await bot.telegram.editMessageText(
    ctx.chat.id, progress.message_id, null,
    `✅ *Broadcast done!*\n📨 Sent: ${sent}\n❌ Failed: ${failed}`,
    { parse_mode: 'Markdown' }
  );
});

bot.command('reportissue', async (ctx) => {
  const report = ctx.message.text.replace(/^\/reportissue\s*/, '').trim();
  if (!report) return ctx.reply('/reportissue <problem>');
  try {
    const sent = await bot.telegram.sendMessage(
      settings.OWNER_TELEGRAM_ID,
      `📢 *Issue*\nFrom: ${ctx.from.first_name} (ID: \`${ctx.from.id}\`)\n\n${report}`,
      { parse_mode: 'Markdown' }
    );
    pendingReplies.set(String(sent.message_id), { userId: ctx.from.id, chatId: ctx.chat.id });
    savePendingReplies();
    await ctx.reply('✅ Reported! Owner will reply to you here.');
  } catch { await ctx.reply('❌ Failed to send.'); }
});

bot.on('message', async (ctx, next) => {
  if (String(ctx.from?.id) !== String(settings.OWNER_TELEGRAM_ID)) return next();
  const replyToId = ctx.message?.reply_to_message?.message_id;
  if (!replyToId) return next();
  const pending = pendingReplies.get(String(replyToId));
  if (!pending) return next();
  try {
    const tg  = bot.telegram;
    const uid = pending.userId;
    const m   = ctx.message;
    const cap = m.caption || m.text || '';
    const extra = { caption: `💬 *Reply from owner:*\n\n${cap}`, parse_mode: 'Markdown' };
    if (m.sticker)    await tg.sendSticker(uid, m.sticker.file_id);
    else if (m.animation)  await tg.sendAnimation(uid, m.animation.file_id, extra);
    else if (m.voice)      await tg.sendVoice(uid, m.voice.file_id, extra);
    else if (m.video_note) await tg.sendVideoNote(uid, m.video_note.file_id);
    else if (m.photo) {
      const photo = m.photo[m.photo.length - 1];
      await tg.sendPhoto(uid, photo.file_id, extra);
    }
    else if (m.video)    await tg.sendVideo(uid, m.video.file_id, extra);
    else if (m.audio)    await tg.sendAudio(uid, m.audio.file_id, extra);
    else if (m.document) await tg.sendDocument(uid, m.document.file_id, extra);
    else await tg.sendMessage(uid, `💬 *Reply from owner:*\n\n${m.text || '[message]'}`, { parse_mode: 'Markdown' });
    pendingReplies.delete(String(replyToId));
    savePendingReplies();
    await ctx.reply('✅ Reply sent to user.');
  } catch { await ctx.reply('❌ Could not reach user.'); }
});

// ─────────────────────────────────────────────────────────────
//   WHATSAPP SESSION STARTER
// ─────────────────────────────────────────────────────────────

async function startWhatsApp(sessionId, telegramChatId = null, pairPhone = null, tgUserId = null, pairingCodeCallback = null) {
  const dir = sessionDir(sessionId);
  ensureDir(dir);

  const { state, saveCreds } = await useMultiFileAuthState(dir);
  const { version }          = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    keepAliveIntervalMs:            15000,
    printQRInTerminal:              false,
    logger:                         pino({ level: 'silent' }),
    auth: {
      creds: state.creds,
      keys:  makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
    },
    browser:                        ['Ubuntu', 'Chrome', '120.0.0.0'],
    syncFullHistory:                false,
    markOnlineOnConnect:            false,
    generateHighQualityLinkPreview: false,
  });

  sock.__sessionId = sessionId;
  const _phoneFromSid = sessionId.split('_').pop();
  if (_phoneFromSid && /^\d{7,}$/.test(_phoneFromSid)) sock.__waNum = _phoneFromSid;
  activeSockets.set(sessionId, sock);
  sock.ev.on('creds.update', saveCreds);

  if (!state.creds.registered && pairPhone) {
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(pairPhone, 'SAMSUNG1');
        if (typeof pairingCodeCallback === 'function') {
          await pairingCodeCallback(code);
        } else if (telegramChatId) {
          const msg = `🔑 *Pairing Code for +${pairPhone}*\n\n\`${code}\`\n\nOpen WhatsApp → Linked Devices → Link a device → Link with phone number`;
          await bot.telegram.sendMessage(telegramChatId, msg, { parse_mode: 'Markdown' });
        }
      } catch (e) {
        if (telegramChatId) bot.telegram.sendMessage(telegramChatId, `❌ Pairing failed: ${e.message}`).catch(()=>{});
      }
    }, 2500);
  }

  sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      activeSockets.delete(sessionId);
      logSession(sessionId, 'disconnected');
      if (code === DisconnectReason.loggedOut) {
        logWarn(sessionId, 'Logged out – deleting session');
        notifiedConnected.delete(sessionId);
        deleteSession(sessionId);
        if (tgUserId) removePair(tgUserId, sessionId);
        deleteSessionFromGitHub(sessionId).catch(() => {});
        if (telegramChatId) bot.telegram.sendMessage(telegramChatId, `🚪 +${sock.__waNum||pairPhone} logged out & session deleted.\nUse /pair to reconnect.`).catch(()=>{});
      } else {
        logWarn(sessionId, 'Reconnecting...');
        setTimeout(() => startWhatsApp(sessionId, telegramChatId, null, tgUserId), 3000);
      }
    }
    if (connection === 'open') {
      const waNum  = numOf(sock.user?.id || '');
      sock.__waNum = waNum;
      if (tgUserId) addPair(tgUserId, sessionId, waNum);
      const c = getWaSettings(waNum);
      if (!c.owner) setWaSetting(waNum, 'owner', waNum);
      logSession(sessionId, 'connected');
      logSuccess(sessionId, `wa.me/${waNum}`);
      if (telegramChatId && !notifiedConnected.has(sessionId)) {
        notifiedConnected.add(sessionId);
        bot.telegram.sendMessage(telegramChatId, `✅ *Connected!*\nNumber: wa.me/${waNum}`, { parse_mode: 'Markdown' }).catch(()=>{});
      }
      runAutoFollow(sock).catch(()=>{});
    }
  });

  // ── WhatsApp Message Handler ──
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const m of messages) {
      if (!m?.message) continue;
      if (m.message.ephemeralMessage) m.message = m.message.ephemeralMessage.message;

      const mtype = m.mtype || Object.keys(m.message || {})[0] || '';
      const body = m.message.conversation || m.message.extendedTextMessage?.text || '';
      const prefix = getWaSettings(sock.__waNum)?.prefix || settings.DEFAULT_PREFIX || '.';

      // ── Handle buypanel@username ──
      const panelMatch = body.match(new RegExp(`^${prefix}buypanel[@\\s](.+)$`));
      if (panelMatch) {
        const username = panelMatch[1].trim();
        const from = m.key.remoteJid;
        const sender = m.key.fromMe ? sock.user.id : m.key.participant || m.key.remoteJid;

        if (!username || username.length < 3) {
          await sock.sendMessage(from, { text: '❌ Username must be at least 3 characters.' }, { quoted: m });
          return;
        }
        const cleanUsername = username.toLowerCase().replace(/[^a-z0-9_-]/g, '');
        if (!cleanUsername || cleanUsername.length < 3) {
          await sock.sendMessage(from, { text: '❌ Only letters, numbers, underscores allowed.' }, { quoted: m });
          return;
        }

        const sessionKey = `${sender}_buypanel`;
        if (!global._pendingPanel) global._pendingPanel = {};
        global._pendingPanel[sessionKey] = { username: cleanUsername };

        await sendPanelList(sock, from, cleanUsername, m);
        return;
      }

      // ── Handle list response ──
      if (mtype === 'listResponseMessage') {
        const selectedId = m.message.listResponseMessage?.singleSelectReply?.selectedRowId;
        if (selectedId && selectedId.startsWith('panel_')) {
          const from = m.key.remoteJid;
          const sender = m.key.fromMe ? sock.user.id : m.key.participant || m.key.remoteJid;

          const panelMap = {
            'panel_5gb':      { ram: 512,  disk: 5120,  cpu: 40, price: 5,  isAdmin: false },
            'panel_10gb':     { ram: 1024, disk: 10240, cpu: 60, price: 10, isAdmin: false },
            'panel_unlimited':{ ram: 0,    disk: 0,     cpu: 0,  price: 8,  isAdmin: false },
            'panel_cpanel':   { ram: 1024, disk: 1024,  cpu: 40, price: 10, isAdmin: true },
          };

          const spec = panelMap[selectedId];
          if (!spec) {
            await sock.sendMessage(from, { text: '❌ Invalid selection.' }, { quoted: m });
            return;
          }

          const sessionKey = `${sender}_buypanel`;
          const pending = global._pendingPanel?.[sessionKey];
          if (!pending || !pending.username) {
            await sock.sendMessage(from, { text: '❌ Session expired. Please start again with buypanel kamau' }, { quoted: m });
            return;
          }
          const username = pending.username;
          delete global._pendingPanel[sessionKey];

          await processPanelPayment(sock, from, sender, username, spec, m, prefix);
          return;
        }
      }

      // ── Handle verifypayment ──
      if (body.startsWith(prefix + 'verifypayment')) {
        const from = m.key.remoteJid;
        const sender = m.key.fromMe ? sock.user.id : m.key.participant || m.key.remoteJid;
        const args = body.slice(prefix.length).trim().split(/\s+/).slice(1);
        const ref = args[0] || null;

        let reference = ref;
        let pending = null;

        if (reference) {
          pending = pendingPayments.get(reference);
          if (!pending) {
            await sock.sendMessage(from, { text: '❌ Payment reference not found.' }, { quoted: m });
            return;
          }
        } else {
          const pendingEntries = Array.from(pendingPayments.entries())
            .filter(([ref2, data]) => data.userId === sender && data.status === 'pending');

          if (pendingEntries.length === 0) {
            await sock.sendMessage(from, { text: '❌ No pending payments found for your account.' }, { quoted: m });
            return;
          }
          const latest = pendingEntries[pendingEntries.length - 1];
          reference = latest[0];
          pending = latest[1];
        }

        if (pending.status === 'success') {
          await sock.sendMessage(from, { text: '✅ This payment was already verified and processed.' }, { quoted: m });
          return;
        }

        await sock.sendMessage(from, { react: { text: '⏳', key: m.key } });
        await sock.sendMessage(from, { text: '⏳ Verifying payment...' }, { quoted: m });

        const verify = await verifyPaystackPayment(reference);
        if (!verify || !verify.status) {
          await sock.sendMessage(from, { text: '❌ Verification failed. Please try again later.' }, { quoted: m });
          return;
        }

        if (verify.data.status === 'success') {
          pending.status = 'success';
          const { username, ram, disk, cpu, isAdmin } = pending;
          try {
            const panelResult = await createPterodactylPanel(username, ram, disk, cpu, isAdmin || false);
            const typeLabel = isAdmin ? '👑 CPANEL' : '📦 ' + (ram === 0 ? 'Unlimited' : `${disk/1024}GB`) + ' Panel';
            const successMsg = `✅ *Panel Created Successfully!*\n\n` +
              `Type: ${typeLabel}\n` +
              `👤 Username: ${panelResult.username}\n` +
              `🔑 Password: ${panelResult.password}\n` +
              `📊 RAM: ${panelResult.ram === 0 ? 'Unlimited' : panelResult.ram + 'MB'}\n` +
              `💾 Disk: ${panelResult.disk === 0 ? 'Unlimited' : panelResult.disk + 'MB'}\n` +
              `⚡ CPU: ${panelResult.cpu === 0 ? 'Unlimited' : panelResult.cpu + '%'}\n` +
              `🔗 Login: ${panelResult.panelDomain}\n\n` +
              `⚠️ Save these credentials!`;
            await sock.sendMessage(from, { text: successMsg }, { quoted: m });
            pendingPayments.delete(reference);
          } catch (e) {
            await sock.sendMessage(from, { text: `❌ Panel creation failed: ${e.message}` }, { quoted: m });
          }
        } else {
          await sock.sendMessage(from, { text: `⏳ Payment status: ${verify.data.status}. Please complete the payment and try again.` }, { quoted: m });
        }
        return;
      }

      // ── Normal message handling ──
      (async () => {
        const chatMeta = { groupName: '' };
        if (m.key.remoteJid?.endsWith('@g.us')) {
          try { const meta = await sock.groupMetadata(m.key.remoteJid); chatMeta.groupName = meta.subject || ''; } catch {}
        }
        await checkAntilink(sock, m);
        await checkAntiMedia(sock, m);
        await handleMessage(sock, m, chatMeta);
      })().catch(e => logError(sessionId, e.message));
    }
  });

  sock.ev.on('messages.delete', (update) => {
    if (!update?.keys?.length) return;
    handleAntiDelete(sock, update).catch(()=>{});
  });

  sock.ev.on('group-participants.update', (update) => {
    handleGroupParticipantsUpdate(sock, update).catch(()=>{});
  });

  sock.ev.on('call', (call) => {
    handleAntiCall(sock, call).catch(()=>{});
  });

  return sock;
}

// ─────────────────────────────────────────────────────────────
//   WHATSAPP PANEL HELPERS
// ─────────────────────────────────────────────────────────────

async function sendPanelList(sock, from, username, quotedMsg) {
  const panelOptions = [
    { id: 'panel_5gb',      title: '💾 5GB Panel',     description: 'Start your VPS with 5GB storage',        ram: 512,  disk: 5120,  cpu: 40, price: 5,  isAdmin: false },
    { id: 'panel_10gb',     title: '📀 10GB Panel',    description: 'Start your VPS with 10GB storage',       ram: 1024, disk: 10240, cpu: 60, price: 10, isAdmin: false },
    { id: 'panel_unlimited',title: '♾️ Unlimited Panel',description: 'No storage limits for your VPS',        ram: 0,    disk: 0,    cpu: 0,  price: 8,  isAdmin: false },
    { id: 'panel_cpanel',   title: '⚙️ cPanel Panel',  description: 'Full cPanel & Webhosting Manager',      ram: 1024, disk: 1024,  cpu: 40, price: 10, isAdmin: true },
  ];

  const sections = [
    {
      title: '⚙️ Panel Selection',
      highlight_label: 'Choose Panel',
      rows: panelOptions.map(opt => ({
        title: opt.title,
        description: opt.description,
        id: opt.id,
      })),
    },
  ];

  const bodyText =
    `🖥️ *Panel Selection*\n` +
    `👤 User: *${username}*\n\n` +
    `Welcome! Choose your perfect VPS plan below:\n` +
    `• 💰 Prices start from just $5\n` +
    `• ⚡ Instant deployment after payment\n` +
    `• 🔒 Secure & reliable hosting\n\n` +
    `👇 Tap the button below to see options.`;

  const interactiveMsg = proto.Message.InteractiveMessage.create({
    body: proto.Message.InteractiveMessage.Body.create({ text: bodyText }),
    footer: proto.Message.InteractiveMessage.Footer.create({ text: `© ${settings.COMPANY || '𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓'}` }),
    header: proto.Message.InteractiveMessage.Header.create({ title: '⚡ Panel Options', hasMediaAttachment: false }),
    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
      buttons: [
        {
          name: 'single_select',
          buttonParamsJson: JSON.stringify({
            title: '📋 Panel Options',
            sections,
          }),
        },
      ],
    }),
    contextInfo: {
      forwardingScore: 1,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: settings.CHANNEL_JID || '120363407629340544@newsletter',
        newsletterName: settings.CHANNEL_NAME || '〖 🟢 SAMSUNG XMD 🟢 〗',
      },
    },
  });

  const msg = {
    ephemeralMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
        interactiveMessage: interactiveMsg,
      },
    },
  };

  const wam = await generateWAMessageFromContent(from, msg, { quoted: quotedMsg });
  await sock.relayMessage(from, wam.message, { messageId: wam.key.id });
}

async function processPanelPayment(sock, from, sender, username, spec, m, prefix) {
  const amount = spec.price;
  const reference = `${spec.isAdmin ? 'CPANEL' : 'PANEL'}-${sender.replace(/[^0-9]/g, '')}-${Date.now()}`;
  const email = `${sender.split('@')[0]}@telegram.bot`;

  const init = await initPaystackPayment(amount, email, reference, {
    user_id: sender,
    username,
    ram: spec.ram,
    disk: spec.disk,
    cpu: spec.cpu,
    price: spec.price,
    isAdmin: spec.isAdmin,
  });

  if (!init || !init.status) {
    await sock.sendMessage(from, { text: '❌ Failed to create payment.' }, { quoted: m });
    return;
  }

  const paymentUrl = init.data.authorization_url;
  pendingPayments.set(reference, {
    userId: sender,
    username,
    ram: spec.ram,
    disk: spec.disk,
    cpu: spec.cpu,
    price: spec.price,
    isAdmin: spec.isAdmin,
    status: 'pending',
  });

  const typeLabel = spec.isAdmin ? '👑 CPANEL' : '📦 ' + (spec.ram === 0 ? 'Unlimited' : `${spec.disk/1024}GB`) + ' Panel';
  const ramDisplay = spec.ram === 0 ? 'Unlimited' : `${spec.ram}MB`;
  const diskDisplay = spec.disk === 0 ? 'Unlimited' : `${spec.disk}MB`;
  const cpuDisplay = spec.cpu === 0 ? 'Unlimited' : `${spec.cpu}%`;

  await sock.sendMessage(from, {
    text:
      `💳 *Complete your payment*\n\n` +
      `Type: ${typeLabel}\n` +
      `Username: ${username}\n` +
      `📊 RAM: ${ramDisplay}\n` +
      `💾 Disk: ${diskDisplay}\n` +
      `⚡ CPU: ${cpuDisplay}\n` +
      `💰 Price: $${spec.price}\n\n` +
      `🔗 Pay here:\n${paymentUrl}\n\n` +
      `After paying, just type *${prefix}verifypayment* – no reference needed.`
  }, { quoted: m });
}

// ─────────────────────────────────────────────────────────────
//   RELOAD & LAUNCH
// ─────────────────────────────────────────────────────────────

async function reloadSessions() {
  await syncSessionsFromGitHub();
  const list = listSessions();
  logInfo('STARTUP', `Reloading ${list.length} session(s)`);
  const allPairs = getAllPairs();
  list.forEach((sid, i) => {
    let tgUserId = null;
    for (const [uid, pairs] of Object.entries(allPairs)) {
      if (pairs.find(p => p.sessionId === sid)) { tgUserId = uid; break; }
    }
    notifiedConnected.add(sid);
    setTimeout(() => startWhatsApp(sid, null, null, tgUserId).catch(e => logError(sid, e.message)), i * 1200);
  });
}

async function launch() {
  process.stdout.write(chalk.magentaBright(`
⠀⠀⠀⣠⠂⢀⣠⡴⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⢤⣄⠀⠐⣄⠀⠀⠀
⠀⢀⣾⠃⢰⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⡆⠸⣧⠀⠀
⢀⣾⡇⠀⠘⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⠁⠀⢹⣧⠀
⢸⣿⠀⠀⠀⢹⣷⣀⣤⣤⣀⣀⣠⣶⠂⠰⣦⡄⢀⣤⣤⣀⣀⣾⠇⠀⠀⠈⣿⡆
⣿⣿⠀⠀⠀⠀⠛⠛⢛⣛⣛⣿⣿⣿⣶⣾⣿⣿⣿⣛⣛⠛⠛⠛⠀⠀⠀⠀⣿⣷
⣿⣿⣀⣀⠀⠀⢀⣴⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⣀⣠⣿⣿
⠛⠻⠿⠿⣿⣿⠟⣫⣶⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣙⠿⣿⣿⠿⠿⠛⠋
⠀⠀⠀⠀⠀⣠⣾⠟⣯⣾⠟⣻⣿⣿⣿⣿⣿⣿⡟⠻⣿⣝⠿⣷⣌⠀⠀⠀⠀⠀
⠀⠀⢀⣤⡾⠛⠁⢸⣿⠇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⢹⣿⠀⠈⠻⣷⣄⡀⠀⠀
⢸⣿⡿⠋⠀⠀⠀⢸⣿⠀⠀⢿⣿⣿⣿⣿⣿⣿⡟⠀⢸⣿⠆⠀⠀⠈⠻⣿⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡀⠀⠘⣿⣿⣿⣿⣿⡿⠁⠀⢸⣿⠀⠀⠀⠀⠀⢸⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡇⠀⠀⠈⢿⣿⣿⡿⠁⠀⠀⢸⣿⠀⠀⠀⠀⠀⣼⣿⠃
⠈⣿⣷⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠈⢻⠟⠁⠀⠀⠀⣼⣿⡇⠀⠀⠀⠀⣿⣿⠀
⠀⢿⣿⡄⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⢰⣿⡟⠀
⠀⠈⣿⣷⠀⠀⠀⢸⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠃⠀⠀⢀⣿⡿⠁⠀
⠀⠀⠈⠻⣧⡀⠀⠀⢻⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⡟⠀⠀⢀⣾⠟⠁⠀⠀
⠀⠀⠀⠀⠀⠁⠀⠀⠈⢿⣿⡆⠀⠀⠀⠀⠀⠀⣸⣿⡟⠀⠀⠀⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡄⠀⠀⠀⠀⣰⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠆⠀⠀⠐⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀`));

  global._startWhatsApp = (...args) => startWhatsApp(...args);

  logInfo('PREMIUM', `Mode: ${premData.premOnly ? 'Premium-only' : 'Public'} | Owners: ${[settings.OWNER_TELEGRAM_ID, ...premData.owners].length} | Prem users: ${premData.premUsers.length}`);
  logInfo('REPLIES', `Loaded ${pendingReplies.size} pending reply(ies) from disk`);
  logInfo('PAYSTACK', PAYSTACK_SECRET ? '✅ Paystack configured' : '❌ Paystack secret missing');
  logInfo('PANEL', PANEL_DOMAIN ? `✅ Panel domain: ${PANEL_DOMAIN}` : '❌ Panel domain missing');

  startPingLoop();
  startSessionWatcher();
  await reloadSessions();
  bot.launch({ dropPendingUpdates: true });
  logSuccess('TELEGRAM', 'Bot running');

  process.once('SIGINT',  () => { bot.stop('SIGINT');  process.exit(0); });
  process.once('SIGTERM', () => { bot.stop('SIGTERM'); process.exit(0); });
}

launch().catch(e => { logError('FATAL', e.message); process.exit(1); });