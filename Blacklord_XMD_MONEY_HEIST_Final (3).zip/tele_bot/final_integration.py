import os
import re

bot_dir = "/home/ubuntu/tele_bot"
case_path = os.path.join(bot_dir, "case.js")
commands_path = os.path.join(bot_dir, "commands")
original_case_path = "/home/ubuntu/original_bot/〖𝐁𝐋Λ𝐂𝐊𝐋𝐎𝐑𝐃 𝐗𝐌𝐃/tele-wa-bot45/case.js"

# 1. Read original case.js
with open(original_case_path, "r", encoding="utf-8") as f:
    content = f.read()

# 2. Identify all triggers in the original file
native_triggers = set()
for line in content.splitlines():
    m = re.search(r"case\s+['\"]([^'\"]+)['\"]\s*:", line.strip())
    if m:
        native_triggers.add(m.group(1).lower().strip())

print(f"Native triggers: {len(native_triggers)}")

# 3. Extract all unique blacklord commands
blacklord_modules = []
seen_triggers = set(native_triggers)

for root, dirs, files in os.walk(commands_path):
    for file in files:
        if file.endswith(".js"):
            filepath = os.path.join(root, file)
            rel_path = "./" + os.path.relpath(filepath, bot_dir).replace("\\", "/")
            category = os.path.basename(root).upper()
            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                    fc = f.read()
                
                name_matches = list(re.finditer(r"name\s*:\s*['\"]([^'\"]+)['\"]", fc))
                if not name_matches: continue
                
                for i, match in enumerate(name_matches):
                    name = match.group(1).lower().strip()
                    start = 0 if i == 0 else name_matches[i-1].end()
                    end = len(fc) if i == len(name_matches)-1 else name_matches[i+1].start()
                    chunk = fc[start:end]
                    
                    aliases = []
                    a_m = re.search(r"aliases\s*:\s*\[([^\]]+)\]", chunk)
                    if a_m: aliases.extend([a.lower().strip() for a in re.findall(r"['\"]([^'\"]+)['\"]", a_m.group(1))])
                    
                    # De-duplicate
                    if name in seen_triggers:
                        new_name = None
                        for a in aliases:
                            if a not in seen_triggers:
                                new_name = a
                                break
                        if new_name:
                            name = new_name
                            aliases = [a for a in aliases if a != new_name]
                        else:
                            continue
                    
                    filtered_aliases = [a for a in aliases if a not in seen_triggers]
                    
                    blacklord_modules.append({
                        "primary": name,
                        "aliases": filtered_aliases,
                        "rel_path": rel_path,
                        "category": category
                    })
                    
                    seen_triggers.add(name)
                    for a in filtered_aliases: seen_triggers.add(a)
            except: pass

# Extra features
extra = [
    {"primary": "carbon", "aliases": ["code"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "magic8", "aliases": ["8ball"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "roast", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "riddle", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "trivia", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "ai", "aliases": ["chatgpt", "gpt", "openai", "gemini"], "rel_path": "./commands/extra/extra_features.js", "category": "AI"}
]
for mod in extra:
    if mod["primary"] not in seen_triggers:
        filtered_a = [a for a in mod["aliases"] if a not in seen_triggers]
        blacklord_modules.append({**mod, "aliases": filtered_a})
        seen_triggers.add(mod["primary"])
        for a in filtered_a: seen_triggers.add(a)

print(f"Integrating {len(blacklord_modules)} blacklord modules.")

# 4. Generate integration code
cases_code = "\n  // ── Ultimate Inclusive Command Integration ──\n"
for mod in blacklord_modules:
    triggers = [mod["primary"]] + mod["aliases"]
    for t in triggers:
        cases_code += f"    case '{t}':\n"
    cases_code += "    {\n"
    cases_code += "      try {\n"
    cases_code += f"        const exported = require('{mod['rel_path']}');\n"
    cases_code += f"        const blacklordCmd = Array.isArray(exported) ? exported.find(c => c.name === '{mod['primary']}') : exported;\n"
    cases_code += "        const extra = { from, sender, pushname, reply: async (text, opts) => await sock.sendMessage(from, { text }, { quoted: m, ...opts }), args, text, prefix: storedPrefix };\n"
    cases_code += "        await blacklordCmd.execute(sock, m, args, extra);\n"
    cases_code += f"      }} catch (err) {{ console.error('[CMD-ERR] {mod['primary']}:', err); await reply('❌ Error: ' + err.message); }}\n"
    cases_code += "      break;\n"
    cases_code += "    }\n"

# 5. Apply Branding and Inject
content = content.replace("BLACKLORD", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Blacklord", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Tony45", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("switch (cmd) {", "switch (cmd) {" + cases_code)

# 6. Final De-duplication (Safety check for entire file)
lines = content.splitlines(keepends=True)
final_lines = []
final_seen = set()

i = 0
while i < len(lines):
    line = lines[i]
    m = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", line.strip())
    if m:
        # Found a case group
        group_lines = []
        group_triggers = []
        j = i
        while j < len(lines):
            curr = lines[j].strip()
            mc = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", curr)
            if mc:
                group_triggers.append(mc.group(1).lower().strip())
                group_lines.append(lines[j])
                j += 1
            elif curr == "" or curr.startswith("//"):
                group_lines.append(lines[j])
                j += 1
            else:
                break
        
        # Body
        body_lines = []
        brace_depth = 0
        while j < len(lines):
            body_lines.append(lines[j])
            brace_depth += lines[j].count("{")
            brace_depth -= lines[j].count("}")
            if (re.search(r"^case\s+['\"]", lines[j].strip()) or lines[j].strip().startswith("default:") or lines[j].strip() == "}") and brace_depth <= 0:
                # We hit the next block
                # But wait, we already appended the trigger-less line to body_lines.
                # Let's remove it if it was a trigger.
                if re.search(r"^case\s+['\"]", lines[j].strip()) or lines[j].strip().startswith("default:") or lines[j].strip() == "}":
                    body_lines.pop()
                    j -= 1
                break
            j += 1
        
        # Filter
        unique_group = []
        for line_text, trigger in zip(group_lines, group_triggers + [None]*len(group_lines)):
            if trigger is None or trigger not in final_seen:
                unique_group.append(line_text)
                if trigger: final_seen.add(trigger)
        
        if any(t in final_seen for t in group_triggers):
            final_lines.extend(unique_group)
            final_lines.extend(body_lines)
        
        i = j + 1
    else:
        final_lines.append(line)
        i += 1

with open(case_path, "w", encoding="utf-8") as f:
    f.writelines(final_lines)

print("Final Integration Complete!")
