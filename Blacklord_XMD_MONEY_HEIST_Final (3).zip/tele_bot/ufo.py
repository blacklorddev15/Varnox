import os
import re

bot_dir = "/home/ubuntu/tele_bot"
case_path = os.path.join(bot_dir, "case.js")
commands_path = os.path.join(bot_dir, "commands")
original_case_path = "/home/ubuntu/original_bot/〖𝐁𝐋Λ𝐂𝐊𝐋𝐎𝐑𝐃 𝐗𝐌𝐃/tele-wa-bot45/case.js"

with open(original_case_path, "r", encoding="utf-8") as f:
    content = f.read()

# Enhanced Reply Helper
enhanced_reply = """const reply = async (text2, opts = {}) => {
    const out = ft(String(text2), sock);
    const c2 = cfg(sock);
    let title = 'REPLY';
    const rawText = m.text || m.message?.conversation || m.message?.extendedTextMessage?.text || '';
    if (rawText) {
        const prefix = c2.prefix || settings.DEFAULT_PREFIX || '.';
        const trimmed = rawText.trim();
        const cmdPart = trimmed.startsWith(prefix) ? trimmed.slice(prefix.length) : trimmed;
        const firstWord = cmdPart.split(/\\s+/)[0] || '';
        if (firstWord) title = firstWord.toUpperCase();
    }
    const styledTitle = ft(title, sock);
    if (c2.iphoneMode) {
        await sock.sendMessage(jid, { text: out, ...opts }, { quoted: m });
        return;
    }
    
    let finalOutput = out;
    if (title !== 'MENU' && title !== 'ALLMENU' && title !== 'HELP') {
        const top = `╭━━•›㘠 @ ${styledTitle} 〙━•⩵꙰ཱི࿐`;
        const indented = out.split('\\n').map(line => line.trim() ? `│ ${line}` : `│`).join('\\n');
        const footer = `╰━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐`;
        finalOutput = blockquote(`${top}\\n${indented}\\n${footer}`);
    }
    
    const contextInfo = {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: settings.CHANNEL_JID || '120363407629340544@newsletter',
            newsletterName: '〖 𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓 〗'
        },
        ...(opts.contextInfo || {})
    };
    await sock.sendMessage(jid, {
        text: finalOutput,
        ...opts,
        contextInfo: contextInfo
    }, { quoted: m });
};"""

start_marker = "const reply = async (text2) => {"
end_pattern = r"\}\, \{ quoted: m \}\);\s*\};"
match = re.search(start_marker, content)
if match:
    start_idx = match.start()
    match_end = re.search(end_pattern, content[start_idx:])
    if match_end:
        end_idx = start_idx + match_end.end()
        content = content[:start_idx] + enhanced_reply + content[end_idx:]

content = content.replace("BLACKLORD", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Blacklord", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Tony45", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("〖 𝐒𝚰𝐋𝚬𝚴𝐂𝚬𝚪 𝚵𝚳𝐃 〗", "〖 𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓 〗")

menu_styles_js = """    case 'menu': {
      await reaction('🌹');
      const style = c.menuStyle || '1';
      const myName = pushname || 'User';
      const myNumber = senderNumber || 'Unknown';
      const myStatus = _isOwner ? '𝗢𝘄𝗻𝒆𝗿' : isPremium ? '𝗣𝗿𝗲𝗺𝒊𝒖𝗺' : '𝗙𝒓𝒆𝒆';
      const myUptime = typeof runtime === 'function' ? runtime(process.uptime()) : formatUptime(process.uptime() * 1000);
      const botName = c.botName || '𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓';
      
      const styles = {
        '1': { h: `•━═ 〘  ${botName}  〙═━•\\n> ╭═━⪩〘⚡𝐁𝝝𝐓 𝐒𝐓Λ𝐓𝐔𝐒⚡ 〙•━•⩵꙰ཱི࿐`, s: `\\n> │⫹⫺ 𝗣𝗿𝗲𝘆        : ${myName}\\n> │⫹⫺ 𝗦𝗶𝗴𝗶𝗹       : ${myNumber}\\n> │⫹⫺ 𝗗𝗼𝗺𝗶𝗻𝗶𝗼𝗻    : ${myStatus}\\n> │⫹⫺ 𝗖𝗼𝘂𝗻𝘁𝗱𝗼𝘄𝗻  : ${myUptime}\\n> ╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐`, p: '> │❍ ', ch: '> ╭═━⪩ 〖  ', cf: '  〗═══━•⩵꙰ཱི࿐', f: '> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐' },
        '2': { h: `┏━━━━『 ${botName} 』━━━━┓`, s: `\\n┃ ⚡ 𝗡𝗮𝗺𝗲: ${myName}\\n┃ ⚡ 𝗨𝗽𝘁𝗶𝗺𝗲: ${myUptime}\\n┗━━━━━━━━━━━━━━━━━━━━┛`, p: '┃ ◈ ', ch: '┏━━『 ', cf: ' 』━━┓', f: '┗━━━━━━━━━━┛' },
        '3': { h: `╔════════════════╗\\n  ${botName}\\n╚════════════════╝`, s: `\\n👤 ${myName}\\n⏱️ ${myUptime}`, p: '  ◦ ', ch: '┌──『 ', cf: ' 』', f: '└─────────' },
        '4': { h: `『 ${botName} 』`, s: `\\n┠ 𝗨𝘀𝗲𝗿: ${myName}\\n┠ 𝗧𝗶𝗺𝗲: ${myUptime}`, p: '┃ ', ch: '┯━『 ', cf: ' 』', f: '┷━━━━' },
        '5': { h: `══【 ${botName} 】══`, s: `\\n◧ 𝗨𝘀𝗲𝗿: ${myName}\\n◧ 𝗨𝗽𝘁𝗶𝗺𝗲: ${myUptime}`, p: '◽ ', ch: '══【 ', cf: ' 】══', f: '════════' },
        '6': { h: `✨ ${botName} ✨`, s: `\\n👤 ${myName}\\n⏳ ${myUptime}`, p: '🔹 ', ch: '💠 ', cf: ' 💠', f: '✨✨✨✨' },
        '7': { h: `◈ ${botName} ◈`, s: `\\n⫹⫺ ${myName}\\n⫹⫺ ${myUptime}`, p: '• ', ch: '◈ ', cf: ' ◈', f: '◈◈◈◈' },
        '8': { h: `『 ${botName} 』`, s: `\\n┠ ${myName}\\n┠ ${myUptime}`, p: '│ ', ch: '╭─ ', cf: ' ─╮', f: '╰────╯' },
        '9': { h: `★ ${botName} ★`, s: `\\n👤 ${myName}\\n🚀 ${myUptime}`, p: '☆ ', ch: '★ ', cf: ' ★', f: '★★★★' },
        '10': { h: `═══『 ${botName} 』═══`, s: `\\n> 👤 ${myName}\\n> 🚀 ${myUptime}`, p: '> ', ch: '══『 ', cf: ' 』══', f: '══════' }
      };
      
      const st = styles[style] || styles['1'];
      let menuText = st.h + st.s + '\\n\\n';
      
      for (const [cat, cmds] of Object.entries(CMDS)) {
        menuText += st.ch + cat + st.cf + '\\n';
        for (const cmd of cmds) {
          menuText += st.p + cmd + '\\n';
        }
        menuText += st.f + '\\n\\n';
      }
      
      const finalMenu = ft(menuText, sock);
      const menuImg = settings.DEFAULT_MENU_IMG || '/home/ubuntu/tele_bot/media/menu.png';
      
      await sock.sendMessage(jid, {
        image: { url: menuImg },
        caption: finalMenu,
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: settings.CHANNEL_JID || '120363407629340544@newsletter',
            newsletterName: '〖 𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓 〗'
          }
        }
      }, { quoted: m });
      break;
    }"""
content = re.sub(r"case\s+['\"]menu['\"]\s*:\s*\{.*?break;\s*\}", menu_styles_js, content, flags=re.DOTALL)

native_triggers = set()
for m in re.finditer(r"case\s+['\"]([^'\"]+)['\"]\s*:", content):
    native_triggers.add(m.group(1).lower().strip())

blacklord_modules = []
seen_in_integration = set(native_triggers)
for root, dirs, files in os.walk(commands_path):
    for file in files:
        if file.endswith(".js"):
            filepath = os.path.join(root, file)
            rel_path = "./" + os.path.relpath(filepath, bot_dir).replace("\\", "/")
            category = os.path.basename(root).upper()
            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                    fc = f.read()
                name_matches = list(re.finditer(r"name\s*:\s*['\"]([^'\"]+)['\"]", fc))
                if not name_matches: continue
                for i, match in enumerate(name_matches):
                    name = match.group(1).lower().strip()
                    aliases = []
                    a_m = re.search(r"aliases\s*:\s*\[([^\]]+)\]", fc[match.end():match.end()+500])
                    if a_m: aliases.extend([a.lower().strip() for a in re.findall(r"['\"]([^'\"]+)['\"]", a_m.group(1))])
                    if name in seen_in_integration:
                        new_name = next((a for a in aliases if a not in seen_in_integration), None)
                        if new_name:
                            name = new_name
                            aliases = [a for a in aliases if a != new_name]
                        else: continue
                    filtered_aliases = [a for a in aliases if a not in seen_in_integration]
                    blacklord_modules.append({"primary": name, "aliases": filtered_aliases, "rel_path": rel_path, "category": category})
                    seen_in_integration.add(name)
                    for a in filtered_aliases: seen_in_integration.add(a)
            except: pass

cases_code = "\n  // ── Ultimate Inclusive Command Integration ──\n"
for mod in blacklord_modules:
    triggers = [mod["primary"]] + mod["aliases"]
    for t in triggers: cases_code += f"    case '{t}':\n"
    cases_code += "    {\n      try {\n"
    cases_code += f"        const exported = require('{mod['rel_path']}');\n"
    cases_code += f"        const blacklordCmd = Array.isArray(exported) ? exported.find(c => c.name === '{mod['primary']}') : exported;\n"
    cases_code += "        const extra = { from, sender, pushname, reply: async (text, opts) => await reply(text, opts), args, text, prefix: storedPrefix };\n"
    cases_code += "        await blacklordCmd.execute(sock, m, args, extra);\n"
    cases_code += f"      }} catch (err) {{ console.error('[CMD-ERR] {mod['primary']}:', err); await reply('❌ Error: ' + err.message); }}\n"
    cases_code += "      break;\n    }\n"

content = content.replace("switch (cmd) {", "switch (cmd) {" + cases_code, 1)

lines = content.splitlines(keepends=True)
final_lines = []
final_seen = set()
i = 0
while i < len(lines):
    line = lines[i]
    m = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", line.strip())
    if m:
        trigger = m.group(1).lower().strip()
        if trigger in final_seen:
            if "{" in line or (i+1 < len(lines) and "{" in lines[i+1].strip()):
                depth = 0
                started = False
                j = i
                while j < len(lines):
                    depth += lines[j].count("{")
                    depth -= lines[j].count("}")
                    if "{" in lines[j]: started = True
                    if "break;" in lines[j] and depth <= 0:
                        j += 1
                        if j < len(lines) and lines[j].strip() == "}": j += 1
                        break
                    if started and depth <= 0 and j+1 < len(lines) and (re.search(r"^case\s+['\"]", lines[j+1].strip()) or lines[j+1].strip().startswith("default:")):
                        j += 1
                        break
                    j += 1
                i = j
                continue
        else:
            final_seen.add(trigger)
            final_lines.append(line)
    else:
        final_lines.append(line)
    i += 1

with open(case_path, "w", encoding="utf-8") as f:
    f.writelines(final_lines)

print("UFO Integration Complete!")
