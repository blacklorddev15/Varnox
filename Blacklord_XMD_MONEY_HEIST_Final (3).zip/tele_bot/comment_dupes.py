import re

path = "/home/ubuntu/tele_bot/case.js"
with open(path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

triggers = []
for i, line in enumerate(lines):
    m = re.search(r"case\s+['\"]([^'\"]+)['\"]\s*:", line.strip())
    if m:
        triggers.append((m.group(1).lower().strip(), i))

seen = {}
to_comment = []
for t, idx in triggers:
    if t in seen:
        to_comment.append(idx)
    else:
        seen[t] = idx

for idx in to_comment:
    lines[idx] = "// " + lines[idx]

with open(path, 'w', encoding='utf-8') as f:
    f.writelines(lines)

print(f"Commented out {len(to_comment)} duplicate case lines.")
