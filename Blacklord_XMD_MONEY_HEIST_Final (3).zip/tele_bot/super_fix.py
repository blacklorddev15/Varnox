import re
import os

path = "/home/ubuntu/tele_bot/case.js"

with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Basic normalization
content = re.sub(r"}\s*case", "}\n    case", content)
content = re.sub(r":\s*{", ":\n    {", content)

lines = content.splitlines()
new_lines = []
seen_triggers = set()

# Find switch start
switch_found = False
i = 0
while i < len(lines):
    line = lines[i]
    if "switch (cmd) {" in line or "switch (command) {" in line:
        new_lines.append(line)
        switch_found = True
        i += 1
        break
    new_lines.append(line)
    i += 1

if not switch_found:
    print("Switch not found!")
    exit(1)

# Process cases inside switch
while i < len(lines):
    line_text = lines[i].strip()
    
    # Check if we hit the end of the switch (approximate)
    if line_text == "default:" or line_text == "} // end switch" or (line_text == "}" and i > len(lines) - 10):
        new_lines.append(lines[i])
        i += 1
        continue

    m = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", line_text)
    if m:
        # We found a case! Let's extract the whole group
        group_triggers = []
        j = i
        while j < len(lines):
            curr_stripped = lines[j].strip()
            m_sub = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", curr_stripped)
            if m_sub:
                group_triggers.append(m_sub.group(1).lower().strip())
                j += 1
            elif curr_stripped == "" or curr_stripped.startswith("//"):
                j += 1
            else:
                break
        
        # Now find the body
        body_lines = []
        brace_depth = 0
        started = False
        while j < len(lines):
            b_line = lines[j]
            body_lines.append(b_line)
            brace_depth += b_line.count("{")
            brace_depth -= b_line.count("}")
            if "{" in b_line: started = True
            
            if "break;" in b_line and brace_depth <= 0:
                j += 1
                # Catch closing brace
                if j < len(lines) and lines[j].strip() == "}":
                    body_lines.append(lines[j])
                    j += 1
                break
            if started and brace_depth <= 0 and ("case" in lines[j] or "default" in lines[j]):
                # Safety break if we missed the break; but hit the next case
                break
            j += 1
            
        # Filter triggers
        unique_in_group = []
        for t in group_triggers:
            if t not in seen_triggers:
                unique_in_group.append(t)
                seen_triggers.add(t)
        
        if unique_in_group:
            for t in unique_in_group:
                new_lines.append(f"    case '{t}':")
            new_lines.extend(body_lines)
        else:
            print(f"Skipping duplicate group: {group_triggers}")
        
        i = j
    else:
        new_lines.append(lines[i])
        i += 1

with open(path, 'w', encoding='utf-8') as f:
    f.write("\n".join(new_lines))

print("Super Fix complete!")
