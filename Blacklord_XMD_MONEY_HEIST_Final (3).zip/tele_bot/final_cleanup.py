import re
import os

path = "/home/ubuntu/tele_bot/case.js"

with open(path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

# 1. Identify all triggers and their line indices
triggers = []
for i, line in enumerate(lines):
    m = re.search(r"case\s+['\"]([^'\"]+)['\"]\s*:", line.strip())
    if m:
        triggers.append((m.group(1).lower().strip(), i))

# 2. Find duplicates to remove (keep the FIRST occurrence)
seen = set()
to_delete_indices = []
for t, idx in triggers:
    if t in seen:
        to_delete_indices.append(idx)
    else:
        seen.add(t)

# 3. For each duplicate trigger, we need to decide if we delete just the line or the whole block
# If the duplicate is part of a block that has NO unique triggers, delete the whole block.
# If the block has other unique triggers, just comment out/delete the duplicate case line.

# We'll use a safer approach: just comment out the duplicate case lines first.
for idx in to_delete_indices:
    lines[idx] = "// DUPLICATE: " + lines[idx]

# 4. Perform global branding replacements
content = "".join(lines)
content = content.replace("BLACKLORD", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Blacklord", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Tony45", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("〖 𝐒𝚰𝐋𝚬𝚴𝐂𝚬𝚪 𝚵𝚳𝐃 〗", "〖 𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓 〗")

# 5. Save
with open(path, 'w', encoding='utf-8') as f:
    f.write(content)

print(f"Commented out {len(to_delete_indices)} duplicate triggers and applied branding.")
