import os
import re

filepath = "/home/ubuntu/Tony45_extracted/blacklord_ultra/blacklord-Ultra-Clean (1)/commands/ai/ai.js"
with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
    file_content = f.read()

name_matches = list(re.finditer(r"name\s*:\s*['\"]([^'\"]+)['\"]", file_content))
print(f"Found {len(name_matches)} names in ai.js")
for m in name_matches:
    print(f" - {m.group(1)}")
