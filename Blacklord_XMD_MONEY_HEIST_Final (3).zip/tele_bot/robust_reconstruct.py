import re
import os

def robust_reconstruct(path):
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Find switch start
    start_match = re.search(r"switch\s*\(\s*(cmd|command)\s*\)\s*\{", content)
    if not start_match:
        print("Switch not found!")
        return
    
    header = content[:start_match.end()]
    rest = content[start_match.end():]
    
    # 2. Parse blocks
    blocks = []
    current_pos = 0
    
    while current_pos < len(rest):
        # Skip whitespace
        while current_pos < len(rest) and rest[current_pos].isspace():
            current_pos += 1
        
        if current_pos >= len(rest): break
        
        # Check if we hit the end of the switch
        if rest[current_pos] == '}':
            break
            
        # Extract triggers
        triggers = []
        while current_pos < len(rest):
            m_case = re.match(r"case\s+['\"]([^'\"]+)['\"]\s*:", rest[current_pos:])
            m_def = re.match(r"default\s*:", rest[current_pos:])
            
            if m_case:
                triggers.append(m_case.group(1).lower().strip())
                current_pos += m_case.end()
                # Skip whitespace
                while current_pos < len(rest) and rest[current_pos].isspace():
                    current_pos += 1
            elif m_def:
                triggers.append("default")
                current_pos += m_def.end()
                while current_pos < len(rest) and rest[current_pos].isspace():
                    current_pos += 1
            else:
                break
        
        if not triggers:
            # We hit something that isn't a case but isn't the end of the switch
            # This is likely orphaned code or comments. Let's just consume until next case or }
            k = current_pos
            while k < len(rest):
                if rest[k:].lstrip().startswith("case ") or rest[k:].lstrip().startswith("default:") or rest[k:].lstrip().startswith("}"):
                    break
                k += 1
            current_pos = k
            continue
            
        # Extract body
        body_start = current_pos
        brace_depth = 0
        in_string = False
        string_char = ''
        k = body_start
        
        while k < len(rest):
            char = rest[k]
            # String handling
            if char in ["'", '"', '`'] and (k == 0 or rest[k-1] != '\\'):
                if not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char:
                    in_string = False
            
            if not in_string:
                if char == '{': brace_depth += 1
                elif char == '}': brace_depth -= 1
                
                # End of block condition: brace_depth 0 and next is case/default/}
                if brace_depth <= 0:
                    # Check for break; and then the end
                    # We'll just look for the next trigger or end of switch
                    lookahead = rest[k+1:].lstrip()
                    if lookahead.startswith("case ") or lookahead.startswith("default:") or lookahead.startswith("}"):
                        k += 1
                        break
            k += 1
        
        blocks.append({
            "triggers": triggers,
            "body": rest[body_start:k]
        })
        current_pos = k
        
    footer = rest[current_pos:]
    
    # 3. Reconstruct
    seen = set()
    final_blocks = []
    for b in blocks:
        unique = []
        for t in b["triggers"]:
            if t == "default":
                unique.append(t)
            elif t not in seen:
                unique.append(t)
                seen.add(t)
        
        if unique:
            final_blocks.append({
                "triggers": unique,
                "body": b["body"]
            })
            
    with open(path, 'w', encoding='utf-8') as f:
        f.write(header)
        for b in final_blocks:
            f.write("\n")
            for t in b["triggers"]:
                if t == "default": f.write("    default:\n")
                else: f.write(f"    case '{t}':\n")
            f.write(b["body"])
        f.write(footer)

robust_reconstruct("/home/ubuntu/tele_bot/case.js")
print("Robust Reconstruction complete!")
