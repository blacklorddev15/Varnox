import re

path = "/home/ubuntu/tele_bot/case.js"
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# Fix broken single-quoted strings that were split across lines
content = re.sub(r"'\s*\n\s*'", r"\\n", content)
content = re.sub(r"'\s*\n\s*;", r"\\n';", content)

# Specific fixes for the menu code
content = content.replace("st.cf + '\n';", "st.cf + '\\n';")
content = content.replace("cmd + '\n';", "cmd + '\\n';")
content = content.replace("st.f + '\n\n';", "st.f + '\\n\\n';")

with open(path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Newlines fixed!")
