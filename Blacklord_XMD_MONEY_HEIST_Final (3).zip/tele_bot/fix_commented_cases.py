import re

path = "/home/ubuntu/tele_bot/case.js"
with open(path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
i = 0
while i < len(lines):
    line = lines[i]
    if "// DUPLICATE: " in line and "case" in line and "{" in line:
        # This line starts a block. We need to comment out the whole block until break;
        brace_depth = 0
        started = False
        j = i
        while j < len(lines):
            brace_depth += lines[j].count("{")
            brace_depth -= lines[j].count("}")
            if "{" in lines[j]: started = True
            lines[j] = "// " + lines[j]
            if "break;" in lines[j] and brace_depth <= 0:
                j += 1
                if j < len(lines) and lines[j].strip() == "}":
                    lines[j] = "// " + lines[j]
                    j += 1
                break
            if started and brace_depth <= 0 and (re.search(r"^case\s+['\"]", lines[j+1].strip()) if j+1 < len(lines) else False):
                j += 1
                break
            j += 1
        i = j
    else:
        new_lines.append(line)
        i += 1

with open(path, 'w', encoding='utf-8') as f:
    f.writelines(lines)

print("Commented out entire duplicate blocks.")
