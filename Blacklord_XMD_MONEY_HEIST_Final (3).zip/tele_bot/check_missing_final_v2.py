import re

def normalize_text(text):
    # Map mathematical italic characters back to ASCII
    italic_map = {
        '𝒂': 'a', '𝒃': 'b', '𝒄': 'c', '𝒅': 'd', '𝒆': 'e', '𝒇': 'f', '𝒈': 'g', '𝒉': 'h', '𝒊': 'i', '𝒋': 'j', '𝒌': 'k', '𝒍': 'l', '𝒎': 'm', '𝒏': 'n', '𝒐': 'o', '𝒑': 'p', '𝒒': 'q', '𝒓': 'r', '𝒔': 's', '𝒕': 't', '𝒖': 'u', '𝒗': 'v', '𝒘': 'w', '𝒙': 'x', '𝒚': 'y', '𝒛': 'z',
        '𝑨': 'a', '𝑩': 'b', '𝑪': 'c', '𝑫': 'd', '𝑬': 'e', '𝑭': 'f', '𝑮': 'g', '𝑯': 'h', '𝑰': 'i', '𝑱': 'j', '𝑲': 'k', '𝑳': 'l', '𝑴': 'm', '𝑵': 'n', '𝑶': 'o', '𝑷': 'p', '𝑸': 'q', '𝑹': 'r', '𝑺': 's', '𝑻': 't', '𝑼': 'u', '𝑽': 'v', '𝑾': 'w', '𝑿': 'x', '𝒀': 'y', '𝒁': 'z',
        '𝟎': '0', '𝟏': '1', '𝟐': '2', '𝟑': '3', '𝟒': '4', '𝟓': '5', '𝟔': '6', '𝟕': '7', '𝟖': '8', '𝟗': '9'
    }
    res = ""
    for char in text:
        res += italic_map.get(char, char)
    return res

case_path = "/home/ubuntu/tele_bot/case.js"
pasted_path = "/home/ubuntu/upload/pasted_content.txt"

with open(case_path, "r", encoding="utf-8") as f:
    case_content = f.read()

active_triggers = set(re.findall(r"case\s+['\"]([^'\"]+)['\"]", case_content))

with open(pasted_path, "r", encoding="utf-8") as f:
    pasted_content = f.read()

pasted_cmds = set()
for line in pasted_content.splitlines():
    # Normalize the whole line first
    line = normalize_text(line)
    
    m = re.search(r"│❍\s*(\w+)", line)
    if m: pasted_cmds.add(m.group(1).lower().strip())
    
    m2 = re.search(r"\.(\w+)", line)
    if m2: pasted_cmds.add(m2.group(1).lower().strip())

missing = []
for pc in pasted_cmds:
    if pc not in active_triggers:
        missing.append(pc)

print(f"Found {len(missing)} missing commands from pasted_content.txt after normalization:")
for m in sorted(missing):
    print(f" - {m}")
