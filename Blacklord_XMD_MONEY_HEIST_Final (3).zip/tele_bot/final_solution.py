import re
import os

def final_solution(path):
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Find switch start
    start_match = re.search(r"switch\s*\(\s*(cmd|command)\s*\)\s*\{", content)
    if not start_match: 
        print("Switch not found!")
        return
    
    header = content[:start_match.end()]
    rest = content[start_match.end():]
    
    lines = rest.splitlines(keepends=True)
    new_lines = []
    seen_triggers = set()
    
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        
        # Check for case or default
        m_case = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", stripped)
        m_def = re.search(r"^default\s*:", stripped)
        
        if m_case or m_def:
            # Found a case/default group start
            group_triggers = []
            j = i
            while j < len(lines):
                s = lines[j].strip()
                mc = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", s)
                md = re.search(r"^default\s*:", s)
                if mc:
                    group_triggers.append(mc.group(1).lower().strip())
                    j += 1
                elif md:
                    group_triggers.append("default")
                    j += 1
                elif s == "" or s.startswith("//"):
                    j += 1
                else:
                    break
            
            # Find body
            body_lines = []
            brace_depth = 0
            started = False
            while j < len(lines):
                b_line = lines[j]
                body_lines.append(b_line)
                brace_depth += b_line.count("{")
                brace_depth -= b_line.count("}")
                if "{" in b_line: started = True
                
                if "break;" in b_line and brace_depth <= 0:
                    j += 1
                    if j < len(lines) and lines[j].strip() == "}":
                        body_lines.append(lines[j])
                        j += 1
                    break
                # Safety break
                if started and brace_depth <= 0 and (re.search(r"^case\s+['\"]", lines[j].strip()) or lines[j].strip().startswith("default:") or lines[j].strip() == "}"):
                    break
                j += 1
            
            # Filter
            unique = []
            for t in group_triggers:
                if t == "default":
                    unique.append(t)
                elif t not in seen_triggers:
                    unique.append(t)
                    seen_triggers.add(t)
            
            if unique:
                for t in unique:
                    if t == "default": new_lines.append("    default:\n")
                    else: new_lines.append(f"    case '{t}':\n")
                new_lines.extend(body_lines)
            i = j
        else:
            new_lines.append(line)
            i += 1
            
    with open(path, 'w', encoding='utf-8') as f:
        f.write(header + "".join(new_lines))

final_solution("/home/ubuntu/tele_bot/case.js")
print("Final Solution complete!")
