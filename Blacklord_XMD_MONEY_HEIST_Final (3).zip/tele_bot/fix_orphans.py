import re

path = "/home/ubuntu/tele_bot/case.js"
with open(path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
i = 0
in_switch = False
last_was_case_end = False
buffer = []

while i < len(lines):
    line = lines[i]
    stripped = line.strip()
    
    if "switch (cmd) {" in line:
        in_switch = True
        new_lines.append(line)
        i += 1
        continue
    
    if in_switch:
        if stripped.startswith("case '") or stripped.startswith('case "'):
            # We found a case. If we have a buffer of orphaned code, clear it.
            if buffer:
                print(f"Removing orphaned code before {stripped}")
                buffer = []
            new_lines.append(line)
            last_was_case_end = False
        elif "break;" in stripped and ("}" in stripped or (i+1 < len(lines) and "}" in lines[i+1])):
            # Potential end of a case block
            new_lines.append(line)
            if "}" in stripped:
                last_was_case_end = True
            else:
                # Catch the closing brace on next line
                i += 1
                new_lines.append(lines[i])
                last_was_case_end = True
        elif last_was_case_end:
            # We are after a case end, but before the next case.
            # If this is not whitespace or comment, it's orphaned.
            if stripped == "" or stripped.startswith("//") or stripped.startswith("/*"):
                new_lines.append(line)
            else:
                # Orphaned code!
                buffer.append(line)
                # Don't append to new_lines yet
        else:
            new_lines.append(line)
    else:
        new_lines.append(line)
    
    i += 1

with open(path, 'w', encoding='utf-8') as f:
    f.writelines(new_lines)

print("Orphaned bodies removed!")
