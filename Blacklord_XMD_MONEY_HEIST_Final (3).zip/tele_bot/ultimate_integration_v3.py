import os
import re
import json

bot_dir = "/home/ubuntu/tele_bot"
original_case_path = os.path.join(bot_dir, "case.js")
commands_path = os.path.join(bot_dir, "commands")

with open(original_case_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

# 1. Identify the integration block and extract NATIVE content
native_lines = []
in_integration = False
for line in lines:
    if "// ── Ultimate Inclusive Command Integration ──" in line:
        in_integration = True
        continue
    if in_integration:
        # We assume the integration block ends where the first native case after it starts
        # In our case, we know it was inserted before case 'menu':
        if "case 'menu':" in line and "case 'menu': {" in line:
            in_integration = False
            native_lines.append(line)
        continue
    native_lines.append(line)

native_content = "".join(native_lines)

# 2. Identify all NATIVE triggers
native_triggers = set()
for line in native_lines:
    line = line.strip()
    if line.startswith("case '") or line.startswith('case "'):
        m = re.search(r"case\s+['\"]([^'\"]+)['\"]", line)
        if m:
            native_triggers.add(m.group(1).lower().strip())

print(f"Found {len(native_triggers)} native triggers.")

# 3. Extract ALL blacklord commands
all_blacklord_modules = []
for root, dirs, files in os.walk(commands_path):
    for file in files:
        if file.endswith(".js"):
            filepath = os.path.join(root, file)
            rel_path = "./" + os.path.relpath(filepath, bot_dir).replace("\\", "/")
            category = os.path.basename(root).upper()
            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                    file_content = f.read()
                
                # Find name and aliases
                name_matches = list(re.finditer(r"name\s*:\s*['\"]([^'\"]+)['\"]", file_content))
                if not name_matches: continue
                
                for i, match in enumerate(name_matches):
                    name = match.group(1).lower().strip()
                    start = 0 if i == 0 else name_matches[i-1].end()
                    end = len(file_content) if i == len(name_matches)-1 else name_matches[i+1].start()
                    chunk = file_content[start:end]
                    
                    aliases = []
                    a_m = re.search(r"aliases\s*:\s*\[([^\]]+)\]", chunk)
                    if a_m: aliases.extend([a.lower().strip() for a in re.findall(r"['\"]([^'\"]+)['\"]", a_m.group(1))])
                    
                    all_blacklord_modules.append({
                        "primary": name,
                        "aliases": list(set(aliases)),
                        "rel_path": rel_path,
                        "category": category
                    })
            except: pass

# Add Extra features
extra_features = [
    {"primary": "carbon", "aliases": ["code"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "magic8", "aliases": ["8ball"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "roast", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "riddle", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "trivia", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "ai", "aliases": ["chatgpt", "gpt", "openai", "gemini"], "rel_path": "./commands/extra/extra_features.js", "category": "AI"}
]
all_blacklord_modules.extend(extra_features)

# 4. Filter and De-duplicate
final_modules = []
seen_globally = set(native_triggers)

for mod in all_blacklord_modules:
    primary = mod["primary"]
    aliases = mod["aliases"]
    
    # If primary is already seen, try to promote an alias
    if primary in seen_globally:
        new_primary = None
        for a in aliases:
            if a not in seen_globally:
                new_primary = a
                break
        if new_primary:
            primary = new_primary
            aliases = [a for a in aliases if a != new_primary]
        else:
            continue # Skip this module entirely, all triggers conflict
    
    # Filter aliases
    filtered_aliases = [a for a in aliases if a not in seen_globally]
    
    # Add to final list
    final_modules.append({
        "primary": primary,
        "aliases": filtered_aliases,
        "rel_path": mod["rel_path"],
        "category": mod["category"]
    })
    
    # Mark as seen
    seen_globally.add(primary)
    for a in filtered_aliases:
        seen_globally.add(a)

print(f"Integrating {len(final_modules)} unique command modules.")

# 5. Generate JS code
cases_code = "\n  // ── Ultimate Inclusive Command Integration ──\n"
for mod in final_modules:
    triggers = [mod["primary"]] + mod["aliases"]
    cases_code += "    "
    for t in triggers:
        cases_code += f"case '{t}':\n    "
    
    cases_code += "{\n"
    cases_code += "      try {\n"
    cases_code += f"        const exported = require('{mod['rel_path']}');\n"
    cases_code += f"        const blacklordCmd = Array.isArray(exported) ? exported.find(c => c.name === '{mod['primary']}') : exported;\n"
    cases_code += "        const extra = { from, sender, pushname, reply: async (text, opts) => await sock.sendMessage(from, { text }, { quoted: m, ...opts }), args, text, prefix: storedPrefix };\n"
    cases_code += "        await blacklordCmd.execute(sock, m, args, extra);\n"
    cases_code += f"      }} catch (err) {{ console.error('[CMD-ERR] {mod['primary']}:', err); await reply('❌ Error: ' + err.message); }}\n"
    cases_code += "      break;\n"
    cases_code += "    }\n"

# 6. Inject back into case.js
new_content = ""
in_switch = False
injected = False

for line in native_lines:
    if "switch (command) {" in line:
        new_content += line
        new_content += cases_code
        injected = True
        continue
    new_content += line

with open(original_case_path, "w", encoding="utf-8") as f:
    f.write(new_content)

print("Ultimate integration V3 complete!")
