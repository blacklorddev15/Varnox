import os
import re

bot_dir = "/home/ubuntu/tele_bot"
case_path = os.path.join(bot_dir, "case.js")
commands_path = os.path.join(bot_dir, "commands")
original_case_path = "/home/ubuntu/original_bot/〖𝐁𝐋Λ𝐂𝐊𝐋𝐎𝐑𝐃 𝐗𝐌𝐃/tele-wa-bot45/case.js"

# 1. Read original case.js
with open(original_case_path, "r", encoding="utf-8") as f:
    content = f.read()

# 2. Extract ALL triggers from the original file (including nested ones)
all_native_triggers = set()
for m in re.finditer(r"case\s+['\"]([^'\"]+)['\"]\s*:", content):
    all_native_triggers.add(m.group(1).lower().strip())

# 3. Extract blacklord commands and filter
blacklord_modules = []
seen_in_integration = set()
for root, dirs, files in os.walk(commands_path):
    for file in files:
        if file.endswith(".js"):
            filepath = os.path.join(root, file)
            rel_path = "./" + os.path.relpath(filepath, bot_dir).replace("\\", "/")
            category = os.path.basename(root).upper()
            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                    fc = f.read()
                name_matches = list(re.finditer(r"name\s*:\s*['\"]([^'\"]+)['\"]", fc))
                if not name_matches: continue
                for i, match in enumerate(name_matches):
                    name = match.group(1).lower().strip()
                    start = 0 if i == 0 else name_matches[i-1].end()
                    end = len(fc) if i == len(name_matches)-1 else name_matches[i+1].start()
                    chunk = fc[start:end]
                    aliases = []
                    a_m = re.search(r"aliases\s*:\s*\[([^\]]+)\]", chunk)
                    if a_m: aliases.extend([a.lower().strip() for a in re.findall(r"['\"]([^'\"]+)['\"]", a_m.group(1))])
                    
                    if name in all_native_triggers or name in seen_in_integration:
                        new_name = None
                        for a in aliases:
                            if a not in all_native_triggers and a not in seen_in_integration:
                                new_name = a
                                break
                        if new_name:
                            name = new_name
                            aliases = [a for a in aliases if a != new_name]
                        else: continue
                    
                    filtered_aliases = [a for a in aliases if a not in all_native_triggers and a not in seen_in_integration]
                    blacklord_modules.append({"primary": name, "aliases": filtered_aliases, "rel_path": rel_path, "category": category})
                    seen_in_integration.add(name)
                    for a in filtered_aliases: seen_in_integration.add(a)
            except: pass

extra = [
    {"primary": "carbon", "aliases": ["code"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "magic8", "aliases": ["8ball"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "roast", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "riddle", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "trivia", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "ai", "aliases": ["chatgpt", "gpt", "openai", "gemini"], "rel_path": "./commands/extra/extra_features.js", "category": "AI"}
]
for mod in extra:
    if mod["primary"] not in all_native_triggers and mod["primary"] not in seen_in_integration:
        filtered_a = [a for a in mod["aliases"] if a not in all_native_triggers and a not in seen_in_integration]
        blacklord_modules.append({**mod, "aliases": filtered_a})
        seen_in_integration.add(mod["primary"])
        for a in filtered_a: seen_in_integration.add(a)

# 4. Generate integration code
cases_code = "\n  // ── Ultimate Inclusive Command Integration ──\n"
for mod in blacklord_modules:
    triggers = [mod["primary"]] + mod["aliases"]
    for t in triggers: cases_code += f"    case '{t}':\n"
    cases_code += "    {\n      try {\n"
    cases_code += f"        const exported = require('{mod['rel_path']}');\n"
    cases_code += f"        const blacklordCmd = Array.isArray(exported) ? exported.find(c => c.name === '{mod['primary']}') : exported;\n"
    cases_code += "        const extra = { from, sender, pushname, reply: async (text, opts) => await reply(text, opts), args, text, prefix: storedPrefix };\n"
    cases_code += "        await blacklordCmd.execute(sock, m, args, extra);\n"
    cases_code += f"      }} catch (err) {{ console.error('[CMD-ERR] {mod['primary']}:', err); await reply('❌ Error: ' + err.message); }}\n"
    cases_code += "      break;\n    }\n"

# 5. Apply Branding and Enhanced Reply
enhanced_reply = """const reply = async (text2, opts = {}) => {
    const out = ft(String(text2), sock);
    const c2 = cfg(sock);
    let title = 'REPLY';
    const rawText = m.text || m.message?.conversation || m.message?.extendedTextMessage?.text || '';
    if (rawText) {
        const prefix = c2.prefix || settings.DEFAULT_PREFIX || '.';
        const trimmed = rawText.trim();
        const cmdPart = trimmed.startsWith(prefix) ? trimmed.slice(prefix.length) : trimmed;
        const firstWord = cmdPart.split(/\\s+/)[0] || '';
        if (firstWord) title = firstWord.toUpperCase();
    }
    const styledTitle = ft(title, sock);
    if (c2.iphoneMode) {
        await sock.sendMessage(jid, { text: out, ...opts }, { quoted: m });
        return;
    }
    const top = `╭━━•›〘 @ ${styledTitle} 〙━•⩵꙰ཱི࿐`;
    const indented = out.split('\\n').map(line => line.trim() ? `│ ${line}` : `│`).join('\\n');
    const footer = `╰━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐`;
    const boxed = `${top}\\n${indented}\\n${footer}`;
    const blockquoted = blockquote(boxed);
    const contextInfo = {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: settings.CHANNEL_JID || '120363407629340544@newsletter',
            newsletterName: settings.CHANNEL_NAME || '〖 𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓 〗'
        },
        ...(opts.contextInfo || {})
    };
    await sock.sendMessage(jid, {
        text: blockquoted,
        ...opts,
        contextInfo: contextInfo
    }, { quoted: m });
};"""

start_marker = "const reply = async (text2) => {"
end_pattern = r"\}\, \{ quoted: m \}\);\s*\};"
match = re.search(start_marker, content)
if match:
    start_idx = match.start()
    match_end = re.search(end_pattern, content[start_idx:])
    if match_end:
        end_idx = start_idx + match_end.end()
        content = content[:start_idx] + enhanced_reply + content[end_idx:]

content = content.replace("BLACKLORD", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Blacklord", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Tony45", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("〖 𝐒𝚰𝐋𝚬𝚴𝐂𝚬𝚪 𝚵𝚳𝐃 〗", "〖 𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓 〗")

# 6. Inject Integration Code
content = content.replace("switch (cmd) {", "switch (cmd) {" + cases_code, 1)

# 7. Final De-duplication (Keep first occurrence)
lines = content.splitlines(keepends=True)
final_lines = []
final_seen = set()
i = 0
while i < len(lines):
    line = lines[i]
    m = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", line.strip())
    if m:
        trigger = m.group(1).lower().strip()
        if trigger in final_seen:
            # Duplicate trigger line! Comment it out.
            final_lines.append("// DUPLICATE: " + line)
            # If this line started a block, we need to comment out the whole block.
            if "{" in line or (i+1 < len(lines) and "{" in lines[i+1].strip()):
                brace_depth = 0
                started = False
                j = i
                while j < len(lines):
                    brace_depth += lines[j].count("{")
                    brace_depth -= lines[j].count("}")
                    if "{" in lines[j]: started = True
                    if j != i: final_lines.append("// " + lines[j])
                    if "break;" in lines[j] and brace_depth <= 0:
                        j += 1
                        if j < len(lines) and lines[j].strip() == "}":
                            final_lines.append("// " + lines[j])
                            j += 1
                        break
                    if started and brace_depth <= 0 and j+1 < len(lines) and (re.search(r"^case\s+['\"]", lines[j+1].strip()) or lines[j+1].strip().startswith("default:") or lines[j+1].strip() == "}"):
                        j += 1
                        break
                    j += 1
                i = j
                continue
        else:
            final_seen.add(trigger)
            final_lines.append(line)
    else:
        final_lines.append(line)
    i += 1

with open(case_path, "w", encoding="utf-8") as f:
    f.writelines(final_lines)

print("One True Fix complete!")
