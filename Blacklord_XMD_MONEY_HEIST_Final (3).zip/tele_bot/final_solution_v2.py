import re
import os

def final_solution(path):
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Find switch start
    start_match = re.search(r"switch\s*\(\s*(cmd|command)\s*\)\s*\{", content)
    if not start_match: 
        print("Switch not found!")
        return
    
    header = content[:start_match.end()]
    rest = content[start_match.end():]
    
    lines = rest.splitlines(keepends=True)
    new_lines = []
    seen_triggers = set()
    
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        
        # Check for case or default
        m_case = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", stripped)
        m_def = re.search(r"^default\s*:", stripped)
        
        if m_case or m_def:
            # Found a case/default group start
            group_triggers = []
            j = i
            while j < len(lines):
                s = lines[j].strip()
                mc = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", s)
                md = re.search(r"^default\s*:", s)
                if mc:
                    group_triggers.append(mc.group(1).lower().strip())
                    j += 1
                elif md:
                    group_triggers.append("default")
                    j += 1
                elif s == "" or s.startswith("//"):
                    j += 1
                else:
                    break
            
            # Find body: Everything until the next case, default, or the final switch brace
            body_lines = []
            while j < len(lines):
                s = lines[j].strip()
                # We need to be careful not to stop at cases inside nested switches
                # But in case.js, there are very few nested switches in the main handler.
                # A safe bet is to check if the line is exactly "case '...':" or "default:" at a low indentation.
                if (re.search(r"^case\s+['\"]", s) or s.startswith("default:")) and (lines[j].startswith("    case") or lines[j].startswith("case")):
                    break
                if s == "} // end switch" or s == "}":
                    # Check if this } is the end of the main switch
                    # If there are no more cases after this, it's likely the end.
                    remaining = "".join(lines[j+1:])
                    if "case '" not in remaining and "default:" not in remaining:
                        break
                body_lines.append(lines[j])
                j += 1
            
            # Filter
            unique = []
            for t in group_triggers:
                if t == "default":
                    unique.append(t)
                elif t not in seen_triggers:
                    unique.append(t)
                    seen_triggers.add(t)
            
            if unique:
                for t in unique:
                    if t == "default": new_lines.append("    default:\n")
                    else: new_lines.append(f"    case '{t}':\n")
                new_lines.extend(body_lines)
            i = j
        else:
            new_lines.append(line)
            i += 1
            
    with open(path, 'w', encoding='utf-8') as f:
        f.write(header + "".join(new_lines))

# Before running, restore the clean-ish version (the one after V4 integration)
# Actually, I'll just restore the original again and re-run V4 integration, then run this.
# But I already have the V4 integration results in case.js.
# I will just restore the original and run a combined script.
