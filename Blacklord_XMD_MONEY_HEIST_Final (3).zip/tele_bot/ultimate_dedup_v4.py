import re
import os

path = "/home/ubuntu/tele_bot/case.js"

with open(path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
seen_triggers = set()

i = 0
while i < len(lines):
    line = lines[i]
    stripped = line.strip()
    
    # Match case 'trigger': or case "trigger":
    m = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", stripped)
    if m:
        # 1. Extract the case group (all consecutive case lines)
        group_data = [] # List of (line_text, trigger_name)
        j = i
        while j < len(lines):
            curr_line = lines[j].strip()
            m_sub = re.search(r"^case\s+['\"]([^'\"]+)['\"]\s*:", curr_line)
            if m_sub:
                group_data.append((lines[j], m_sub.group(1).lower().strip()))
                j += 1
            elif curr_line == "" or curr_line.startswith("//"):
                # Keep comments/whitespace within the group but don't count as triggers
                group_data.append((lines[j], None))
                j += 1
            else:
                break
        
        # 2. Extract the body (until break; and closing brace)
        body_lines = []
        brace_depth = 0
        while j < len(lines):
            body_lines.append(lines[j])
            brace_depth += lines[j].count("{")
            brace_depth -= lines[j].count("}")
            if "break;" in lines[j] and brace_depth <= 0:
                j += 1
                # Catch trailing closing brace if it's on its own line
                if j < len(lines) and lines[j].strip() == "}":
                    body_lines.append(lines[j])
                    j += 1
                break
            j += 1
        
        # 3. Filter the triggers in the group
        unique_group_lines = []
        any_new_trigger = False
        
        for line_text, trigger in group_data:
            if trigger is None:
                unique_group_lines.append(line_text)
            elif trigger not in seen_triggers:
                unique_group_lines.append(line_text)
                seen_triggers.add(trigger)
                any_new_trigger = True
            else:
                print(f"Removing duplicate trigger line: {trigger}")
        
        # 4. Decide whether to keep the block
        if any_new_trigger:
            new_lines.extend(unique_group_lines)
            new_lines.extend(body_lines)
        else:
            print(f"Skipping entire duplicate block for triggers: {[d[1] for d in group_data if d[1]]}")
        
        i = j
    else:
        new_lines.append(line)
        i += 1

with open(path, 'w', encoding='utf-8') as f:
    f.writelines(new_lines)

print("Ultimate De-duplication V4 complete!")
