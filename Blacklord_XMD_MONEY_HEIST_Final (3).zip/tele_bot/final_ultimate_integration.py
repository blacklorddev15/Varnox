import os
import re

bot_dir = "/home/ubuntu/tele_bot"
case_path = os.path.join(bot_dir, "case.js")
commands_path = os.path.join(bot_dir, "commands")
original_case_path = "/home/ubuntu/original_bot/〖𝐁𝐋Λ𝐂𝐊𝐋𝐎𝐑𝐃 𝐗𝐌𝐃/tele-wa-bot45/case.js"

# 1. Read original case.js
with open(original_case_path, "r", encoding="utf-8") as f:
    content = f.read()

# 2. Update the reply helper in the content to support opts and box style
# We find the reply helper and replace it with our enhanced version
reply_helper_pattern = r"const reply = async \(text2\) => \{.*?await sock\.sendMessage\(jid, \{.*?text: blockquoted,.*?contextInfo: contextInfo.*?\}, \{ quoted: m \}\);.*?\};"
enhanced_reply = """const reply = async (text2, opts = {}) => {
    const out = ft(String(text2), sock);
    const c2 = cfg(sock);
    let title = 'REPLY';
    const rawText = m.text || m.message?.conversation || m.message?.extendedTextMessage?.text || '';
    if (rawText) {
        const prefix = c2.prefix || settings.DEFAULT_PREFIX || '.';
        const trimmed = rawText.trim();
        const cmdPart = trimmed.startsWith(prefix) ? trimmed.slice(prefix.length) : trimmed;
        const firstWord = cmdPart.split(/\\s+/)[0] || '';
        if (firstWord) title = firstWord.toUpperCase();
    }
    const styledTitle = ft(title, sock);
    if (c2.iphoneMode) {
        await sock.sendMessage(jid, { text: out, ...opts }, { quoted: m });
        return;
    }
    const top = `╭━━•›〘 @ ${styledTitle} 〙━•⩵꙰ཱི࿐`;
    const indented = out.split('\\n').map(line => line.trim() ? `│ ${line}` : `│`).join('\\n');
    const footer = `╰━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐`;
    const boxed = `${top}\\n${indented}\\n${footer}`;
    const blockquoted = blockquote(boxed);
    const contextInfo = {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: settings.CHANNEL_JID || '120363407629340544@newsletter',
            newsletterName: settings.CHANNEL_NAME || '〖 𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓 〗'
        },
        ...(opts.contextInfo || {})
    };
    await sock.sendMessage(jid, {
        text: blockquoted,
        ...opts,
        contextInfo: contextInfo
    }, { quoted: m });
};"""

# Robustly find and replace the reply helper
start_marker = "const reply = async (text2) => {"
end_marker = "}, { quoted: m });\n};"
if start_marker in content:
    start_idx = content.find(start_marker)
    # Find the closing part of the sendMessage call followed by };
    # We look for the pattern that ends the reply function
    end_pattern = r"\}\, \{ quoted: m \}\);\s*\};"
    match = re.search(end_pattern, content[start_idx:])
    if match:
        end_idx = start_idx + match.end()
        content = content[:start_idx] + enhanced_reply + content[end_idx:]
    else:
        print("Could not find end of reply helper")
else:
    print("Could not find start of reply helper")

# 3. Identify ALL triggers in the original file
all_native_triggers = set()
for m in re.finditer(r"case\s+['\"]([^'\"]+)['\"]\s*:", content):
    all_native_triggers.add(m.group(1).lower().strip())

# 4. Extract blacklord commands
blacklord_modules = []
seen_in_integration = set()

for root, dirs, files in os.walk(commands_path):
    for file in files:
        if file.endswith(".js"):
            filepath = os.path.join(root, file)
            rel_path = "./" + os.path.relpath(filepath, bot_dir).replace("\\", "/")
            category = os.path.basename(root).upper()
            try:
                with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                    fc = f.read()
                
                name_matches = list(re.finditer(r"name\s*:\s*['\"]([^'\"]+)['\"]", fc))
                if not name_matches: continue
                
                for i, match in enumerate(name_matches):
                    name = match.group(1).lower().strip()
                    start = 0 if i == 0 else name_matches[i-1].end()
                    end = len(fc) if i == len(name_matches)-1 else name_matches[i+1].start()
                    chunk = fc[start:end]
                    
                    aliases = []
                    a_m = re.search(r"aliases\s*:\s*\[([^\]]+)\]", chunk)
                    if a_m: aliases.extend([a.lower().strip() for a in re.findall(r"['\"]([^'\"]+)['\"]", a_m.group(1))])
                    
                    if name in all_native_triggers or name in seen_in_integration:
                        new_name = None
                        for a in aliases:
                            if a not in all_native_triggers and a not in seen_in_integration:
                                new_name = a
                                break
                        if new_name:
                            name = new_name
                            aliases = [a for a in aliases if a != new_name]
                        else: continue
                    
                    filtered_aliases = [a for a in aliases if a not in all_native_triggers and a not in seen_in_integration]
                    blacklord_modules.append({"primary": name, "aliases": filtered_aliases, "rel_path": rel_path, "category": category})
                    seen_in_integration.add(name)
                    for a in filtered_aliases: seen_in_integration.add(a)
            except: pass

# Extra features
extra = [
    {"primary": "carbon", "aliases": ["code"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "magic8", "aliases": ["8ball"], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "roast", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "riddle", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "trivia", "aliases": [], "rel_path": "./commands/extra/extra_features.js", "category": "EXTRA"},
    {"primary": "ai", "aliases": ["chatgpt", "gpt", "openai", "gemini"], "rel_path": "./commands/extra/extra_features.js", "category": "AI"}
]
for mod in extra:
    if mod["primary"] not in all_native_triggers and mod["primary"] not in seen_in_integration:
        filtered_a = [a for a in mod["aliases"] if a not in all_native_triggers and a not in seen_in_integration]
        blacklord_modules.append({**mod, "aliases": filtered_a})
        seen_in_integration.add(mod["primary"])
        for a in filtered_a: seen_in_integration.add(a)

# 5. Generate integration code using the BOXED reply
cases_code = "\n  // ── Ultimate Inclusive Command Integration ──\n"
for mod in blacklord_modules:
    triggers = [mod["primary"]] + mod["aliases"]
    for t in triggers: cases_code += f"    case '{t}':\n"
    cases_code += "    {\n      try {\n"
    cases_code += f"        const exported = require('{mod['rel_path']}');\n"
    cases_code += f"        const blacklordCmd = Array.isArray(exported) ? exported.find(c => c.name === '{mod['primary']}') : exported;\n"
    # USE THE BOXED REPLY HELPER HERE
    cases_code += "        const extra = { from, sender, pushname, reply: async (text, opts) => await reply(text, opts), args, text, prefix: storedPrefix };\n"
    cases_code += "        await blacklordCmd.execute(sock, m, args, extra);\n"
    cases_code += f"      }} catch (err) {{ console.error('[CMD-ERR] {mod['primary']}:', err); await reply('❌ Error: ' + err.message); }}\n"
    cases_code += "      break;\n    }\n"

# 6. Apply Branding
content = content.replace("BLACKLORD", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Blacklord", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("Tony45", "𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓")
content = content.replace("〖 𝐒𝚰𝐋𝚬𝚴𝐂𝚬𝚪 𝚵𝚳𝐃 〗", "〖 𝐌𝐎𝐍𝐄𝐘 𝐇𝐄𝐈𝐒𝐓 〗")

# 7. Inject into main switch
content = content.replace("switch (cmd) {", "switch (cmd) {" + cases_code, 1)

with open(case_path, "w", encoding="utf-8") as f:
    f.write(content)

print("Final Ultimate Integration complete!")
