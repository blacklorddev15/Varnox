import re

path = "/home/ubuntu/tele_bot/case.js"
to_delete = [4283, 9346, 9369, 9392, 9424, 9446, 9475, 9497, 9756, 9775, 9792, 9815, 9834, 9860, 9861, 9878, 9879, 9895, 9896, 10816, 11415, 12650, 12664, 12678, 12692, 12706, 12720, 12721, 12735, 12749, 12763, 12830, 13957, 14356, 14727, 15229, 15230]

with open(path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Sort in reverse to delete without shifting
to_delete.sort(reverse=True)

for ln in to_delete:
    idx = ln - 1
    if idx >= len(lines): continue
    
    line = lines[idx]
    # Check if it's a block start
    if "{" in line or (idx + 1 < len(lines) and "{" in lines[idx+1].strip()):
        # Find end of block
        j = idx
        brace_depth = 0
        started = False
        while j < len(lines):
            brace_depth += lines[j].count("{")
            brace_depth -= lines[j].count("}")
            if "{" in lines[j]: started = True
            if "break;" in lines[j] and brace_depth <= 0:
                j += 1
                if j < len(lines) and lines[j].strip() == "}":
                    j += 1
                break
            if started and brace_depth <= 0 and (re.search(r"^case\s+['\"]", lines[j].strip()) or lines[j].strip().startswith("default:") or lines[j].strip() == "}"):
                break
            j += 1
        print(f"Deleting block from line {ln} to {j}")
        del lines[idx:j]
    else:
        # Just a case line
        print(f"Deleting single case line {ln}")
        del lines[idx]

with open(path, 'w', encoding='utf-8') as f:
    f.writelines(lines)

print("Line-based de-duplication complete!")
