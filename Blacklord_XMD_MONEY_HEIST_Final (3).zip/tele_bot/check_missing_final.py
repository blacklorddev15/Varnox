import re

case_path = "/home/ubuntu/tele_bot/case.js"
pasted_path = "/home/ubuntu/upload/pasted_content.txt"

with open(case_path, "r", encoding="utf-8") as f:
    case_content = f.read()

active_triggers = set(re.findall(r"case\s+['\"]([^'\"]+)['\"]", case_content))

with open(pasted_path, "r", encoding="utf-8") as f:
    pasted_content = f.read()

# Extract words that look like commands (starting with dot or just words in a list)
pasted_cmds = set()
for line in pasted_content.splitlines():
    # Look for patterns like "│❍ command" or ".command"
    m = re.search(r"│❍\s*(\w+)", line)
    if m: pasted_cmds.add(m.group(1).lower().strip())
    
    m2 = re.search(r"\.(\w+)", line)
    if m2: pasted_cmds.add(m2.group(1).lower().strip())

missing = []
for pc in pasted_cmds:
    if pc not in active_triggers:
        missing.append(pc)

print(f"Found {len(missing)} missing commands from pasted_content.txt:")
for m in sorted(missing):
    print(f" - {m}")
