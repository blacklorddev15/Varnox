import os

path = "/home/ubuntu/tele_bot/case.js"
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

# Fix the broken menu strings
content = content.replace("st.s + '\n\n';", "st.s + '\\n\\n';")
content = content.replace("st.cf + '\n';", "st.cf + '\\n';")
content = content.replace("cmd + '\n';", "cmd + '\\n';")
content = content.replace("st.f + '\n\n';", "st.f + '\\n\\n';")

# Handle the actual broken newlines that were injected
content = content.replace("st.s + '\n\n';", "st.s + '\\n\\n';")
content = content.replace("st.cf + '\n\n';", "st.cf + '\\n\\n';")

# Use a more aggressive replacement for the specific broken line
import re
content = re.sub(r"st\.s \+ '\s*\n\s*';", "st.s + '\\n\\n';", content)
content = re.sub(r"st\.cf \+ '\s*\n\s*';", "st.cf + '\\n';", content)
content = re.sub(r"cmd \+ '\s*\n\s*';", "cmd + '\\n';", content)
content = re.sub(r"st\.f \+ '\s*\n\s*';", "st.f + '\\n\\n';", content)

with open(path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Direct content fix complete!")
