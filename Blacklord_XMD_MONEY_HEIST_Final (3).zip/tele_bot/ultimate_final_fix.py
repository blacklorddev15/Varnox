import os

bot_dir = "/home/ubuntu/tele_bot"
case_path = os.path.join(bot_dir, "case.js")
original_case_path = "/home/ubuntu/original_bot/〖𝐁𝐋Λ𝐂𝐊𝐋𝐎𝐑𝐃 𝐗𝐌𝐃/tele-wa-bot45/case.js"

# We will restart from original, apply UFO, and fix newlines BEFORE injecting
with open(original_case_path, "r", encoding="utf-8") as f:
    content = f.read()

# Run the ufo script logic but fixing the string templates first
with open("/home/ubuntu/tele_bot/ufo.py", "r", encoding="utf-8") as f:
    ufo_code = f.read()

# Fix the broken newlines in ufo.py itself!
ufo_code = ufo_code.replace("let menuText = st.h + st.s + '\\n\\n';", "let menuText = st.h + st.s + '\\\\n\\\\n';")
ufo_code = ufo_code.replace("menuText += st.ch + cat + st.cf + '\\n';", "menuText += st.ch + cat + st.cf + '\\\\n';")
ufo_code = ufo_code.replace("menuText += st.p + cmd + '\\n';", "menuText += st.p + cmd + '\\\\n';")
ufo_code = ufo_code.replace("menuText += st.f + '\\n\\n';", "menuText += st.f + '\\\\n\\\\n';")

# Run it
with open("/home/ubuntu/tele_bot/ufo_fixed.py", "w", encoding="utf-8") as f:
    f.write(ufo_code)

print("Fixed UFO script ready.")
